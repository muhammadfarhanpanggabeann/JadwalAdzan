# Jadwal Adzan (Android)

Aplikasi jadwal salat dengan:
- **GPS** perangkat untuk lokasi (nama kota otomatis jika ada internet)
- **Waktu salat dihitung offline** (metode Kemenag RI: Subuh 20°, Isya 18°, Ashar Syafi'i, ihtiyat +2 menit)
- **Alarm pra-adzan** dengan menit yang bisa diatur per salat (1–180 menit) + saklar per salat
- **Notifikasi / suara adzan** saat waktu tiba
- Tetap bunyi **saat app ditutup** dan **setelah HP restart** (AlarmManager + foreground service + boot receiver)

## Cara membuat APK

### Opsi A — Android Studio
1. Buka folder ini di Android Studio (Hedgehog atau lebih baru), tunggu Gradle sync.
2. Colok HP (USB debugging aktif) → tombol Run. Atau *Build ▸ Build APK(s)*.

### Opsi B — GitHub (tanpa install apa pun)
1. Upload folder ini ke repo GitHub baru.
2. Tab **Actions ▸ Build APK ▸ Run workflow**.
3. Unduh `JadwalAdzan-debug-apk` dari bagian Artifacts, lalu pasang di HP.

## Suara adzan & alarm (MP3)
Ada dua cara:
1. **Dari aplikasi (disarankan):** bagian *Suara (MP3)* ▸ pilih file MP3 dari HP untuk adzan dan/atau alarm pra-adzan. File disalin ke penyimpanan app, jadi tetap bunyi walau file asli dihapus. Tombol *Pakai suara bawaan* mengembalikan ke semula.
2. **Dari kode:** taruh `adzan.mp3` / `alarm_pre.mp3` di `app/src/main/res/raw/` lalu build ulang.

Urutan prioritas: MP3 pilihan ▸ file di res/raw ▸ nada bawaan HP. Kalau file rusak, otomatis pindah ke cadangan berikutnya.

## Matikan dengan tombol volume
Saat adzan/alarm sedang bunyi, tekan tombol volume (naik atau turun) untuk menghentikannya, termasuk saat layar terkunci. Bisa dimatikan lewat saklar *Matikan adzan/alarm dengan tombol volume*.

## Agar alarm andal
Di aplikasi: izinkan notifikasi, lokasi, alarm tepat waktu, dan matikan penghematan baterai.
Di HP Xiaomi/Oppo/Vivo/Realme/Samsung: aktifkan juga *Autostart / Mulai otomatis* dan kunci app di Recent Apps.

## Struktur kode
| File | Fungsi |
|---|---|
| `PrayerTimes.kt` | Hitung waktu salat |
| `Scheduler.kt` | Jadwalkan alarm 3 hari ke depan |
| `AlarmReceiver.kt` | Dipanggil OS saat alarm tiba, jadwalkan ulang |
| `AdzanService.kt` | Foreground service pemutar suara |
| `BootReceiver.kt` | Jadwal ulang setelah reboot / ganti zona waktu |
| `LocationHelper.kt` | GPS + nama kota |
| `MainActivity.kt` | Tampilan & pengaturan |
