# Jadwal Adzan (Android)

Aplikasi jadwal salat dengan:
- **GPS** perangkat untuk lokasi (nama kota otomatis jika ada internet)
- **Waktu salat dihitung offline** (metode Kemenag RI: Subuh 20°, Isya 18°, Ashar Syafi'i, ihtiyat +2 menit)
- **Alarm pra-adzan** dengan menit yang bisa diatur per salat (1–180 menit) + saklar per salat
- **Notifikasi / suara adzan** saat waktu tiba
- Tetap bunyi **saat app ditutup** dan **setelah HP restart** (AlarmManager + foreground service + boot receiver)

## Cara membuat APK

### Opsi A — Android Studio
1. Buka folder ini di Android Studio (Koala 2024.1.1 atau lebih baru), tunggu Gradle sync.
2. Colok HP (USB debugging aktif) → tombol Run. Atau *Build ▸ Build APK(s)*.

### Opsi B — GitHub (tanpa install apa pun)
1. Upload folder ini ke repo GitHub baru.
2. Tab **Actions ▸ Build APK ▸ Run workflow**.
3. Unduh `JadwalAdzan-debug-apk` dari bagian Artifacts, lalu pasang di HP.

## Chip & layar hitung mundur (satu paket, mengikuti alarm)

Chip dan layar hitung mundur adalah **satu paket yang mengikuti alarm**: tidak ada saklar atau tombol menit tersendiri. Alarm sudah mewakili keduanya: saat alarm berbunyi, chip dan layar hitung mundur muncul bersama dan menghitung mundur menuju adzan (layar hitung mundur menyala begitu layar mati). Kalau alarmnya dimatikan, keduanya ikut tidak ada.

- **Chip:** chip live di status bar (Android 16+; di versi lama notifikasi menetap) + kapsul melayang di atas aplikasi lain bila saklar kapsul (di bagian "Hitung mundur alarm") aktif. Kapsul bisa digeser, menempel ke sisi layar, posisi diingat, ketuk untuk membuka layar hitung mundur. Butuh izin *Muncul di atas aplikasi lain*. Hilang sendiri saat adzan tiba.
- **Layar hitung mundur (gaya AOD):** 10 menit sebelum alarm layar hitung mundur muncul saat layar mati: latar hitam, teks lembut, hitung mundur besar. Jika layar hidup, hitung mundur tetap berjalan di latar belakang tanpa membuka layar ini. Layar ini tidak bisa dimatikan dari dirinya sendiri: menekan tombol daya saat ia tampil akan menyalakannya kembali, dan satu-satunya gestur adalah ketuk dua kali untuk membangunkan layar (layar hitung mundur menutup, layar tetap hidup). Menutup sendiri saat alarm berbunyi. Kecerahannya dapat disesuaikan di pengaturan bersama.
- **Selalu aktif sepanjang hari (opsional):** saklar di pengaturan *Hitung mundur alarm*. Bila aktif, layar hitung mundur menyala setiap kali layar mati kapan pun, menghitung mundur ke adzan berikutnya lalu lanjut otomatis ke adzan sesudahnya. Begitu waktu alarm tiba (sampai adzan), yang dipakai layar hitung mundur alarm, yang menutup saat adzan tiba; mode ini kembali berlaku sesudahnya. Chip status bar bila diketuk membuka aplikasi. Saat layar hidup ia tidak dibuka. Berjalan lewat layanan latar belakang (ada notifikasi tetap); layar tetap menyala selama layar ini tampil, jadi boros baterai. Matikan saklar untuk kembali ke mode mengikuti alarm.

## Suara adzan & alarm (MP3)
Ada dua cara:
1. **Dari aplikasi (disarankan):** bagian *Suara (MP3)* ▸ pilih file MP3 dari HP untuk adzan dan/atau alarm pra-adzan. File disalin ke penyimpanan app, jadi tetap bunyi walau file asli dihapus. Tombol *Pakai suara bawaan* mengembalikan ke semula.
2. **Dari kode:** taruh `adzan.mp3` / `alarm_pre.mp3` di `app/src/main/res/raw/` lalu build ulang.

Urutan prioritas: MP3 pilihan ▸ file di res/raw ▸ nada bawaan HP. Kalau file rusak, otomatis pindah ke cadangan berikutnya.

## Matikan dengan tombol volume
Saat adzan/alarm sedang bunyi, tekan tombol volume (naik atau turun) untuk menghentikannya, termasuk saat layar terkunci. Bisa dimatikan lewat saklar *Matikan adzan/alarm dengan tombol volume*.

Deteksi memantau semua stream volume (alarm, musik, dering, notifikasi) karena tergantung kondisi layar & merek HP, tombol volume bisa mengubah stream yang berbeda. Stream yang sedang mentok di maksimum diturunkan 1 tingkat sementara agar tombol naik maupun turun terdeteksi; semuanya dikembalikan setelah selesai.

Saklar *Naikkan volume alarm otomatis* menaikkan volume alarm ke hampir maksimum saat bunyi, lalu mengembalikannya ke volume semula setelah selesai.

Saat layar terkunci/mati, adzan/alarm menampilkan layar alarm (tombol *Hentikan*) di atas layar kunci; di layar itu tombol volume langsung menghentikan suara. Saat HP sedang dipakai/terbuka, notifikasi muncul biasa dan tombol volume dideteksi lewat pemantauan volume sistem.

### Saat HP sedang dipakai (layar menyala)
Android hanya mengizinkan aplikasi menangkap tombol volume di aplikasi lain lewat layanan **Aksesibilitas**. Di aplikasi, tekan *Aktifkan deteksi tombol volume (Aksesibilitas)* ▸ pilih **Jadwal Adzan** ▸ aktifkan. Layanan ini hanya bereaksi pada tombol volume saat adzan/alarm sedang bunyi dan tidak membaca isi layar. Kalau saklar-nya abu-abu: Pengaturan ▸ Aplikasi ▸ Jadwal Adzan ▸ ⋮ ▸ *Izinkan setelan terbatas*.

## Agar alarm andal
Di aplikasi: izinkan notifikasi, lokasi, alarm tepat waktu, layar alarm di atas layar kunci, tampil di atas aplikasi lain, dan matikan penghematan baterai.
Di HP Xiaomi/Oppo/Vivo/Realme/Samsung: aktifkan juga *Autostart / Mulai otomatis* dan kunci app di Recent Apps.

## Struktur kode
| File | Fungsi |
|---|---|
| `PrayerTimes.kt` | Hitung waktu salat |
| `Scheduler.kt` | Jadwalkan alarm 3 hari ke depan |
| `AlarmReceiver.kt` | Dipanggil OS saat alarm tiba, jadwalkan ulang |
| `AdzanService.kt` | Foreground service pemutar suara |
| `BootReceiver.kt` | Jadwal ulang setelah reboot / ganti zona waktu |
| `LocationHelper.kt` | GPS + nama kota |
| `CountdownActivity.kt` | Layar hitung mundur gaya AOD |
| `AlwaysOnService.kt` | Pengawas layar mati untuk mode selalu aktif + penentu adzan berikutnya |
| `FloatingChipService.kt` | Kapsul melayang yang bisa digeser |
| `MainActivity.kt` | Tampilan & pengaturan |
