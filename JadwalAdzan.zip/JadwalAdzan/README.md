# Jadwal Adzan (Android)

Aplikasi jadwal salat dengan:
- **GPS** perangkat untuk lokasi (nama kota otomatis jika ada internet)
- **Waktu salat dihitung offline** (metode Kemenag RI: Subuh 20°, Isya 18°, Ashar Syafi'i, ihtiyat +2 menit)
- **Alarm pra-adzan** dengan menit yang bisa diatur per salat (1–180 menit) + saklar per salat
- **Notifikasi / suara adzan** saat waktu tiba
- Tetap bunyi **saat app ditutup** dan **setelah HP restart** (AlarmManager + foreground service + boot receiver)

## Cara membuat APK

### Opsi A — Android Studio
1. Buka folder ini di Android Studio (Hedgehog atau lebih baru), tunggu Gradle sync.
2. Colok HP (USB debugging aktif) → tombol Run. Atau *Build ▸ Build APK(s)*.

### Opsi B — GitHub (tanpa install apa pun)
1. Upload folder ini ke repo GitHub baru.
2. Tab **Actions ▸ Build APK ▸ Run workflow**.
3. Unduh `JadwalAdzan-debug-apk` dari bagian Artifacts, lalu pasang di HP.

## Suara adzan
Taruh file audio di `app/src/main/res/raw/`:
- `adzan.mp3` → diputar saat adzan
- `alarm_pre.mp3` (opsional) → diputar saat alarm pra-adzan

Tanpa file itu, dipakai nada bawaan HP. (Aplikasi ini tidak menyertakan audio adzan karena hak ciptanya.)

## Agar alarm andal
Di aplikasi: izinkan notifikasi, lokasi, alarm tepat waktu, dan matikan penghematan baterai.
Di HP Xiaomi/Oppo/Vivo/Realme/Samsung: aktifkan juga *Autostart / Mulai otomatis* dan kunci app di Recent Apps.

## Struktur kode
| File | Fungsi |
|---|---|
| `PrayerTimes.kt` | Hitung waktu salat |
| `Scheduler.kt` | Jadwalkan alarm 3 hari ke depan |
| `AlarmReceiver.kt` | Dipanggil OS saat alarm tiba, jadwalkan ulang |
| `AdzanService.kt` | Foreground service pemutar suara |
| `BootReceiver.kt` | Jadwal ulang setelah reboot / ganti zona waktu |
| `LocationHelper.kt` | GPS + nama kota |
| `MainActivity.kt` | Tampilan & pengaturan |
