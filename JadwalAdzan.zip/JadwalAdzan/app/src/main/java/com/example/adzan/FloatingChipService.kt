package com.example.adzan

import android.animation.ValueAnimator
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Kapsul hitung mundur melayang di atas aplikasi lain (butuh izin "Muncul di atas aplikasi lain").
 * - Bisa digeser bebas; saat dilepas menempel (seperti magnet) ke sisi kiri atau kanan layar terdekat.
 * - Posisi vertikal dan sisi terakhir diingat.
 * - Diketuk: membuka layar hitung mundur.
 * - Hilang sendiri saat adzan tiba.
 * Android tidak mengizinkan overlay di layar kunci; di sana dipakai layar hitung mundur & chip status bar.
 */
class FloatingChipService : Service() {

    companion object {
        private const val NOTIF_ID = 330

        fun start(ctx: Context, prayer: Prayer, at: Long) {
            if (!Prefs(ctx).floatOn) return
            if (!Settings.canDrawOverlays(ctx)) return
            if (at <= System.currentTimeMillis()) return
            try {
                ContextCompat.startForegroundService(
                    ctx,
                    Intent(ctx, FloatingChipService::class.java)
                        .putExtra(Scheduler.EXTRA_PRAYER, prayer.key)
                        .putExtra(Scheduler.EXTRA_TIME, at)
                )
            } catch (_: Exception) {
                // OS menolak start layanan dari latar belakang: chip status bar tetap jalan
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, FloatingChipService::class.java))
            } catch (_: Exception) {}
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { Prefs(this) }
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var bubble: LinearLayout? = null
    private lateinit var tvName: TextView
    private lateinit var tvCount: TextView

    private var targetAt = 0L
    private var prayerKey = Prayer.DZUHUR.key
    private var snapAnimator: ValueAnimator? = null

    // status sentuhan
    private var dragging = false
    private var moved = false
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0

    private val density get() = resources.displayMetrics.density

    private val ticker = object : Runnable {
        override fun run() {
            if (updateText()) handler.postDelayed(this, 1000) else stopSelf()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        val key = intent?.getStringExtra(Scheduler.EXTRA_PRAYER)
        val at = intent?.getLongExtra(Scheduler.EXTRA_TIME, 0L) ?: 0L
        if (key == null || at <= System.currentTimeMillis() || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        prayerKey = key
        targetAt = at
        if (bubble == null) createBubble()
        tvName.text = Prayer.fromKey(key)?.label ?: ""
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        NotificationHelper.ensureChannels(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, NotificationHelper.CH_FLOAT)
            .setSmallIcon(R.drawable.ic_stat_adzan)
            .setContentTitle("Kapsul hitung mundur aktif")
            .setContentText("Hilang sendiri saat adzan tiba")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------ tampilan

    private fun createBubble() {
        val d = density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((14 * d).toInt(), (8 * d).toInt(), (16 * d).toInt(), (8 * d).toInt())
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 100 * d
                setColor(Color.parseColor("#F01B6B4A"))
                setStroke((1 * d).toInt().coerceAtLeast(1), Color.parseColor("#66FFFFFF"))
            }
            alpha = 0.96f
        }
        tvName = TextView(this).apply {
            setTextColor(Color.parseColor("#CFEBDD"))
            textSize = 13f
            setPadding(0, 0, (8 * d).toInt(), 0)
        }
        tvCount = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            text = "00:00"
        }
        root.addView(tvName)
        root.addView(tvCount)

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        // Ukur dulu supaya posisi awal (menempel ke sisi) tepat sebelum tampil
        root.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        bubble = root
        lp.x = sideX(root.measuredWidth)
        lp.y = clampY(prefs.floatY, root.measuredHeight)

        root.setOnTouchListener { _, e -> onTouch(e) }
        // Lebar berubah (mis. hitungan jam muncul): tetap menempel ke sisi yang dipilih
        root.addOnLayoutChangeListener { v, l, _, r, _, oldL, _, oldR, _ ->
            if (!dragging && (r - l) != (oldR - oldL)) v.post { placeAtSide(false) }
        }

        try {
            wm.addView(root, lp)
        } catch (_: Exception) {
            bubble = null
            stopSelf()
        }
    }

    private fun onTouch(e: MotionEvent): Boolean {
        val view = bubble ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                snapAnimator?.cancel()
                dragging = true
                moved = false
                downX = e.rawX
                downY = e.rawY
                startX = lp.x
                startY = lp.y
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                val slop = ViewConfiguration.get(this).scaledTouchSlop
                if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) moved = true
                if (moved) {
                    lp.x = (startX + dx).toInt()
                    lp.y = clampY((startY + dy).toInt(), view.height)
                    safeUpdate()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                if (moved) snapToSide() else if (e.actionMasked == MotionEvent.ACTION_UP) openCountdown()
                return true
            }
        }
        return false
    }

    /** Lepas jari: menempel ke sisi layar terdekat dengan gerakan meluncur. */
    private fun snapToSide() {
        val view = bubble ?: return
        val sw = resources.displayMetrics.widthPixels
        val right = lp.x + view.width / 2 > sw / 2
        prefs.floatRight = right
        prefs.floatY = lp.y
        placeAtSide(true)
    }

    private fun placeAtSide(animate: Boolean) {
        val view = bubble ?: return
        val w = if (view.width > 0) view.width else view.measuredWidth
        val h = if (view.height > 0) view.height else view.measuredHeight
        lp.y = clampY(prefs.floatY, h)
        val tx = sideX(w)
        snapAnimator?.cancel()
        if (!animate) {
            lp.x = tx
            safeUpdate()
            return
        }
        snapAnimator = ValueAnimator.ofInt(lp.x, tx).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                lp.x = it.animatedValue as Int
                safeUpdate()
            }
            start()
        }
    }

    private fun sideX(width: Int): Int {
        val sw = resources.displayMetrics.widthPixels
        val margin = (8 * density).toInt()
        return if (prefs.floatRight) sw - width - margin else margin
    }

    private fun clampY(y: Int, height: Int): Int {
        val sh = resources.displayMetrics.heightPixels
        return y.coerceIn(0, (sh - height).coerceAtLeast(0))
    }

    private fun safeUpdate() {
        val v = bubble ?: return
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
    }

    private fun openCountdown() {
        try {
            startActivity(CountdownActivity.intentFor(this, prayerKey, targetAt))
        } catch (_: Exception) {}
    }

    /** @return false kalau waktu habis */
    private fun updateText(): Boolean {
        val s = (targetAt - System.currentTimeMillis() + 999) / 1000
        if (s <= 0) return false
        tvCount.text = Fmt.countdown(s)
        return true
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        bubble?.post { placeAtSide(false) }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        snapAnimator?.cancel()
        bubble?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        bubble = null
        super.onDestroy()
    }
}
