package com.example.adzan

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

/**
 * Layar alarm yang muncul di atas layar kunci saat adzan/alarm bunyi. Karena ini Activity yang
 * sedang tampil, tombol volume pasti sampai ke sini (cara yang sama dipakai aplikasi jam alarm).
 */
class AlarmActivity : Activity() {
    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_TEXT = "text"
        const val ACTION_FINISHED = "com.example.adzan.ALARM_FINISHED"
    }

    private val closer = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            finishAndRemoveTask()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#102A43"))
            setPadding(64, 64, 64, 64)
        }
        root.addView(TextView(this).apply {
            text = intent.getStringExtra(EXTRA_TITLE) ?: "Adzan"
            setTextColor(Color.WHITE)
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = intent.getStringExtra(EXTRA_TEXT) ?: ""
            setTextColor(Color.parseColor("#BCCCDC"))
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 64)
        })
        root.addView(Button(this).apply {
            text = "Hentikan"
            textSize = 20f
            setOnClickListener { stopAlarm() }
        })
        setContentView(root)

        ContextCompat.registerReceiver(
            this, closer, IntentFilter(ACTION_FINISHED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val k = event.keyCode
        if (k == KeyEvent.KEYCODE_VOLUME_UP || k == KeyEvent.KEYCODE_VOLUME_DOWN ||
            k == KeyEvent.KEYCODE_VOLUME_MUTE
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && Prefs(this).volumeStop) stopAlarm()
            return true // tombol volume tidak diteruskan ke sistem
        }
        return super.dispatchKeyEvent(event)
    }

    private fun stopAlarm() {
        try {
            startService(Intent(this, AdzanService::class.java).setAction(AdzanService.ACTION_STOP))
        } catch (_: Exception) {}
        finishAndRemoveTask()
    }

    override fun onDestroy() {
        try { unregisterReceiver(closer) } catch (_: Exception) {}
        super.onDestroy()
    }
}
