package com.example.adzan

import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.pow

/**
 * Layar hitung mundur bergaya Always-On Display: latar hitam, teks lembut, tampil di atas layar
 * kunci dan menyalakan layar. Kecerahan layar ini diatur sendiri oleh app (sensor cahaya +
 * penyesuaian dari pengguna), tidak mengubah kecerahan sistem. Menutup sendiri saat alarm berbunyi.
 * Layar ini tidak bisa dimatikan dari dirinya sendiri: satu-satunya gestur adalah ketuk dua kali
 * yang MEMBANGUNKAN layar (menutup layar ini, layar tetap hidup), dan bila tombol
 * daya ditekan saat layar ini tampil, FloatingChipService (mode per alarm) atau AlwaysOnService
 * (mode selalu aktif sepanjang hari) menampilkannya kembali. Ia hanya
 * muncul saat layar mati; bila layar menyala dari tempat lain, hitung mundur tetap berjalan
 * di latar belakang dan layar ini tidak dibuka.
 */
class CountdownActivity : Activity(), SensorEventListener {

    companion object {
        private const val MIN_LEVEL = 0.04f      // batas bawah kecerahan (tetap terbaca)
        private const val MAX_LEVEL = 0.90f      // batas atas kecerahan (tidak menyilaukan)
        private const val LUX_MAX = 20000f
        private const val DARK_BELOW_LUX = 40f   // di bawah ini = tema redup
        private const val BRIGHT_ABOVE_LUX = 80f // di atas ini = tema terang (jeda agar tidak berkedip)

        private const val EXTRA_PREVIEW = "preview"
        private const val EXTRA_ALWAYS = "always"

        /**
         * always = layar dibuka oleh mode "selalu aktif" di luar jendela alarm: setelah adzan tiba lanjut
         * ke adzan berikutnya. Tanpa always (layar hitung mundur alarm): menutup saat adzan tiba.
         */
        fun intentFor(ctx: Context, prayerKey: String, at: Long, preview: Boolean = false, always: Boolean = false): Intent =
            Intent(ctx, CountdownActivity::class.java)
                .putExtra(Scheduler.EXTRA_PRAYER, prayerKey)
                .putExtra(Scheduler.EXTRA_TIME, at)
                .putExtra(EXTRA_PREVIEW, preview)
                .putExtra(EXTRA_ALWAYS, always)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        /**
         * Dibuka dari alarm di latar belakang. Dua jalur sekaligus supaya andal:
         * (1) langsung membuka Activity bila izin "Muncul di atas" aktif,
         * (2) notifikasi layar penuh (cara yang sama dipakai layar alarm adzan).
         * Activity bersifat singleTask jadi tidak akan terbuka dua kali.
         */
        fun launch(ctx: Context, prayer: Prayer, at: Long, preview: Boolean = false, always: Boolean = false) {
            if (at <= System.currentTimeMillis()) return
            if (Settings.canDrawOverlays(ctx)) {
                try {
                    ctx.startActivity(intentFor(ctx, prayer.key, at, preview, always))
                } catch (_: Exception) {}
            }
            NotificationHelper.showCountdownFullScreen(ctx, prayer, at, preview, always)
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var tvTitle: TextView
    private lateinit var tvCount: TextView
    private lateinit var tvInfo: TextView

    private var targetAt = 0L
    private var always = false
    private var preview = false
    private var prayerKey: String = Prayer.DZUHUR.key
    private var currentLevel = -1f
    private var smoothLux = -1f
    private var dark = true
    private var gotSensorReading = false

    /** Ketuk dua kali = bangunkan layar: tutup layar hitung mundur, layar tetap menyala (layar kunci / app). */
    private val gestures by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onDoubleTap(e: MotionEvent): Boolean {
                wakeScreen()
                return true
            }
        })
    }

    private fun wakeScreen() {
        // Lepas penahan layar menyala; layar tetap hidup dan batas waktu layar sistem berlaku lagi
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        finishAndRemoveTask()
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (tick()) handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Muncul memudar (lembut), bukan tiba-tiba
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= 34) {
            overrideActivityTransition(OVERRIDE_TRANSITION_OPEN, android.R.anim.fade_in, android.R.anim.fade_out)
        } else {
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(48, 48, 48, 48)
        }
        tvTitle = TextView(this).apply {
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        tvCount = TextView(this).apply {
            textSize = 76f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 16)
            includeFontPadding = false
        }
        tvInfo = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
        }
        root.addView(tvTitle)
        root.addView(tvCount)
        root.addView(tvInfo)
        setContentView(root)

        readIntent(intent)

        // Sebelum sensor memberi data: perkirakan dari waktu (siang/malam menurut jadwal salat)
        val day = isDaytime()
        setDark(!day)
        applyLevel(if (day) 0.70f else 0.10f)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    private fun readIntent(i: Intent) {
        prayerKey = i.getStringExtra(Scheduler.EXTRA_PRAYER) ?: Prayer.DZUHUR.key
        targetAt = i.getLongExtra(Scheduler.EXTRA_TIME, 0L)
        preview = i.getBooleanExtra(EXTRA_PREVIEW, false)
        always = i.getBooleanExtra(EXTRA_ALWAYS, false)
        showTarget()
        // Layar sudah terbuka: notifikasi layar penuh tidak diperlukan lagi
        getSystemService(NotificationManager::class.java).cancel(NotificationHelper.aodId(prayerKey))
        tick()
    }

    /** Mode selalu aktif menghitung mundur ke adzan; mode per alarm ke bunyi alarm. */
    private fun showTarget() {
        val prayer = Prayer.fromKey(prayerKey) ?: Prayer.DZUHUR
        tvTitle.text = "Adzan ${prayer.label}"
        tvInfo.text = "Pukul ${Fmt.time(targetAt)} • ${Prefs(this).city}"
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        val sm = getSystemService(SensorManager::class.java)
        val light = sm?.getDefaultSensor(Sensor.TYPE_LIGHT)
        if (light != null) sm.registerListener(this, light, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        try { getSystemService(SensorManager::class.java)?.unregisterListener(this) } catch (_: Exception) {}
        super.onPause()
    }

    /** @return false kalau waktu habis dan layar ditutup */
    private fun tick(): Boolean {
        val s = (targetAt - System.currentTimeMillis() + 999) / 1000
        if (s <= 0) {
            if (always && !preview) {
                // Mode selalu aktif: lanjut menghitung mundur ke adzan berikutnya
                val (p, at) = NextPrayer.find(this)
                prayerKey = p.key
                targetAt = at
                showTarget()
                return tick()
            }
            finishAndRemoveTask()
            return false
        }
        tvCount.text = if (s >= 3600) {
            String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
        } else {
            String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
        }
        return true
    }

    // ------------------------------------------------------------ kecerahan

    override fun onSensorChanged(event: SensorEvent) {
        val lux = event.values[0]
        smoothLux = if (smoothLux < 0f) lux else smoothLux * 0.8f + lux * 0.2f
        gotSensorReading = true
        applyLevel(levelForLux(smoothLux))
        when {
            dark && smoothLux > BRIGHT_ABOVE_LUX -> setDark(false)
            !dark && smoothLux < DARK_BELOW_LUX -> setDark(true)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    /** Kurva lux -> kecerahan: halus di ruang gelap, naik cepat di cahaya terang. */
    private fun levelForLux(lux: Float): Float {
        val t = (log10(1f + lux) / log10(1f + LUX_MAX)).coerceIn(0f, 1f)
        return MIN_LEVEL + (MAX_LEVEL - MIN_LEVEL) * t.pow(1.6f)
    }

    /** Terapkan kecerahan khusus jendela ini (+ penyesuaian dari pengguna). */
    private fun applyLevel(base: Float) {
        val adjust = Prefs(this).brightAdjust / 100f
        val level = (base + adjust).coerceIn(0.02f, 1f)
        if (abs(level - currentLevel) < 0.02f) return
        currentLevel = level
        val lp = window.attributes
        lp.screenBrightness = level
        window.attributes = lp
    }

    private fun isDaytime(): Boolean {
        return try {
            val zone = ZoneId.systemDefault()
            val p = Prefs(this)
            val t = PrayerCalculator.compute(LocalDate.now(zone), p.lat, p.lon, zone).times
            val now = System.currentTimeMillis()
            now >= t.getValue(Prayer.TERBIT) && now < t.getValue(Prayer.MAGHRIB)
        } catch (_: Exception) {
            true
        }
    }

    /** Redup di ruang gelap (teks lembut), kontras tinggi di ruang terang. */
    private fun setDark(isDark: Boolean) {
        dark = isDark
        if (isDark) {
            tvTitle.setTextColor(Color.parseColor("#8FA3B8"))
            tvCount.setTextColor(Color.parseColor("#C9D6E3"))
            tvInfo.setTextColor(Color.parseColor("#6B7F94"))
        } else {
            tvTitle.setTextColor(Color.parseColor("#BCCCDC"))
            tvCount.setTextColor(Color.WHITE)
            tvInfo.setTextColor(Color.parseColor("#D9E2EC"))
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean =
        gestures.onTouchEvent(event) || super.onTouchEvent(event)
}
