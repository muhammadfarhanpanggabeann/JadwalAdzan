package com.example.adzan

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Jadwalkan ulang alarm setelah reboot, update app, atau perubahan jam/zona waktu. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Scheduler.scheduleAll(context)
    }
}
