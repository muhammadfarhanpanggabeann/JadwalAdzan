package com.example.adzan

import android.app.KeyguardManager
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.VolumeProvider
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.io.File

/**
 * Foreground service yang memainkan suara alarm / adzan, sehingga tetap hidup
 * walau aplikasi ditutup. Tombol "Hentikan" ada di notifikasi.
 *
 * Sumber suara (urut prioritas): MP3 yang dipilih di aplikasi -> `adzan.mp3` /
 * `alarm_pre.mp3` di res/raw -> nada bawaan HP.
 * Bisa dihentikan dengan tombol "Hentikan" atau tombol volume HP.
 */
class AdzanService : Service() {
    companion object {
        const val ACTION_STOP = "com.example.adzan.STOP"

        // Ramp volume beep lembut (detik & skala linear 0..1)
        private const val BEEP_START = 0.05f
        private const val BEEP_PEAK = 0.45f
        private const val BEEP_RAMP_END = 36f
        private const val BEEP_HOLD_END = 42f
        private const val BEEP_FADE_END = 45f

        /** Instance yang sedang jalan (dipakai VolumeKeyService untuk menghentikan suara). */
        @Volatile var current: AdzanService? = null
    }

    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var notifId = 0
    private var title = ""
    private var text = ""
    private var ringType = Scheduler.TYPE_ADZAN
    private var ringPrayerKey: String? = null
    private var ringAt = 0L // untuk alarm pra-adzan: waktu adzan (target hitung mundur)
    private var ringPrayer: Prayer? = null
    private var ringAdzanAt = 0L
    private var ringTest = false

    private val queue = mutableListOf<Uri>()
    private var loop = false

    // Penghentian lewat tombol volume
    private var session: MediaSession? = null
    private var receiverRegistered = false

    // Tombol volume bisa mengubah stream mana saja (alarm / musik / dering), tergantung kondisi
    // layar & merek HP, jadi SEMUA stream dipantau, bukan hanya STREAM_ALARM.
    private val watched = intArrayOf(
        AudioManager.STREAM_ALARM, AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING,
        AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM
    )
    private var baseline = IntArray(watched.size) { -1 }
    private var baseRinger = -1
    private val savedVol = mutableMapOf<Int, Int>() // stream -> volume asli (untuk dikembalikan)

    private val poller = object : Runnable {
        override fun run() {
            if (changed(snapshot(), ringerMode())) {
                onVolumeKey()
                return
            }
            handler.postDelayed(this, 50)
        }
    }
    private val volumeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            // Siaran bisa datang telat akibat pengaturan volume dari aplikasi sendiri,
            // jadi hanya dianggap tombol volume kalau nilainya benar-benar beda dari patokan.
            if (changed(snapshot(), ringerMode())) onVolumeKey()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    fun isRinging(): Boolean = notifId != 0

    fun stopFromKey() {
        handler.post { if (notifId != 0) finish() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            finish()
            return START_NOT_STICKY
        }

        current = this
        val type = intent.getIntExtra(Scheduler.EXTRA_TYPE, Scheduler.TYPE_ADZAN)
        ringType = type
        ringPrayerKey = intent.getStringExtra(Scheduler.EXTRA_PRAYER)
        ringAt = intent.getLongExtra(Scheduler.EXTRA_TIME, 0L)
        val (t, x) = NotificationHelper.contentFor(this, intent)
        title = t
        text = x
        notifId = NotificationHelper.notificationId(intent.getStringExtra(Scheduler.EXTRA_PRAYER), type)
        // Dipakai untuk membuka layar hitung mundur ke adzan begitu alarm pra-adzan dimatikan
        ringPrayer = if (type == Scheduler.TYPE_PRE) Prayer.fromKey(intent.getStringExtra(Scheduler.EXTRA_PRAYER)) else null
        ringAdzanAt = intent.getLongExtra(Scheduler.EXTRA_TIME, 0L)
        ringTest = intent.getBooleanExtra(Scheduler.EXTRA_TEST, false)

        NotificationHelper.ensureChannels(this)
        val n = NotificationHelper.build(
            this, NotificationHelper.CH_ALERT, title, text, ongoing = true, withStop = true
        )
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(notifId, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(notifId, n)
        }

        openAlarmScreen()
        startSound(type)
        return START_NOT_STICKY
    }

    /**
     * Cadangan kalau notifikasi layar penuh diblokir sistem: saat layar mati/terkunci, buka layar
     * alarm langsung. Butuh izin "Muncul di atas" supaya boleh membuka Activity dari latar belakang.
     */
    private fun openAlarmScreen() {
        val terkunci = getSystemService(KeyguardManager::class.java).isKeyguardLocked ||
            !getSystemService(PowerManager::class.java).isInteractive
        if (!terkunci || !Settings.canDrawOverlays(this)) return
        try {
            startActivity(
                Intent(this, AlarmActivity::class.java)
                    .putExtra(AlarmActivity.EXTRA_TITLE, title)
                    .putExtra(AlarmActivity.EXTRA_TEXT, text)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        } catch (_: Exception) {}
    }

    private fun startSound(type: Int) {
        handler.removeCallbacksAndMessages(null)
        disarmVolumeKeys() // bersihkan sisa alarm sebelumnya (mis. dua alarm berurutan)
        stopVibration()
        releasePlayer()
        queue.clear()

        val prefs = Prefs(this)
        // Urutan prioritas: MP3 pilihan pengguna -> res/raw -> nada bawaan HP
        val custom = prefs.soundPath(type)?.let { File(it) }?.takeIf { it.exists() }?.let { Uri.fromFile(it) }
        val name = if (type == Scheduler.TYPE_PRE) "alarm_pre" else "adzan"
        val rawId = resources.getIdentifier(name, "raw", packageName)
        val rawUri = if (rawId != 0) Uri.parse("android.resource://$packageName/$rawId") else null
        val defaultUri = RingtoneManager.getDefaultUri(
            if (type == Scheduler.TYPE_PRE) RingtoneManager.TYPE_ALARM
            else RingtoneManager.TYPE_NOTIFICATION
        )
        // Beep digital lembut (pilihan pengguna, hanya alarm pra-adzan): volume naik pelan
        val beepId = resources.getIdentifier("alarm_beep_lembut", "raw", packageName)
        beepUri = if (type == Scheduler.TYPE_PRE && custom == null &&
            prefs.builtinSound(type) == Prefs.BUILTIN_BEEP && beepId != 0
        ) Uri.parse("android.resource://$packageName/$beepId") else null

        custom?.let { queue.add(it) }
        beepUri?.let { queue.add(it) }
        rawUri?.let { queue.add(it) }
        queue.add(defaultUri)

        val hasFile = custom != null || rawUri != null || beepUri != null
        // Nada bawaan alarm diulang sampai dihentikan / 45 detik
        loop = !hasFile && type == Scheduler.TYPE_PRE
        // Pilihan "Hening 5 menit": tidak ada suara, tapi layar alarm/notifikasi/getar tetap aktif
        val silent = custom == null && prefs.builtinSound(type) == Prefs.BUILTIN_SILENT
        if (silent) queue.clear()
        val maxMs = when {
            silent -> 5 * 60_000L
            // File adzan diputar sampai selesai (mengikuti panjang file); 15 menit hanya pengaman
            hasFile && type == Scheduler.TYPE_ADZAN -> 15 * 60_000L
            beepUri != null -> 48_000L // beep 45 dtk selesai sendiri (fade-out), ini hanya pengaman
            else -> 45_000L
        }
        handler.postDelayed({ finish() }, maxMs)

        prepareVolumes(prefs.autoVolume, prefs.volumeStop)
        if (!silent) playNext()
        if (prefs.vibrate) startVibration()
        if (prefs.volumeStop) armVolumeKeys()
    }

    /** Putar URI berikutnya di antrean; kalau gagal, lanjut ke cadangan (bawaan HP). */
    private fun playNext() {
        releasePlayer()
        while (queue.isNotEmpty()) {
            val uri = queue.removeAt(0)
            val mp = MediaPlayer()
            try {
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                mp.setDataSource(this, uri)
                val ramp = uri == beepUri
                val v0 = if (ramp) BEEP_START else 1f
                mp.setVolume(v0, v0)
                mp.isLooping = loop
                mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
                mp.setOnPreparedListener {
                    it.start()
                    if (ramp) startRamp(it)
                }
                mp.setOnCompletionListener { finish() }
                mp.setOnErrorListener { _, _, _ -> handler.post { playNext() }; true }
                mp.prepareAsync()
                player = mp
                return
            } catch (e: Exception) {
                try { mp.release() } catch (_: Exception) {}
            }
        }
        finish()
    }

    // ------------------------------------------------- ramp volume beep lembut

    private var beepUri: Uri? = null

    /**
     * Volume pemutar (skala linear 0..1): mulai 5% di detik 0, naik halus sampai 45% di detik 36
     * (eksponensial dengan easing S-curve, jadi terasa merata di telinga), ditahan sampai detik 42,
     * lalu fade-out ke 0 sampai detik 45. Hanya mengubah volume pemutar, bukan volume sistem.
     */
    private fun startRamp(mp: MediaPlayer) {
        val t0 = SystemClock.uptimeMillis()
        val step = object : Runnable {
            override fun run() {
                if (player !== mp) return // pemutar sudah diganti / dihentikan
                val t = (SystemClock.uptimeMillis() - t0) / 1000f
                val g = when {
                    t < BEEP_RAMP_END -> {
                        val u = t / BEEP_RAMP_END
                        val s = u * u * (3f - 2f * u) // smoothstep
                        BEEP_START * Math.pow((BEEP_PEAK / BEEP_START).toDouble(), s.toDouble()).toFloat()
                    }
                    t < BEEP_HOLD_END -> BEEP_PEAK
                    else -> {
                        val u = ((t - BEEP_HOLD_END) / (BEEP_FADE_END - BEEP_HOLD_END)).coerceIn(0f, 1f)
                        BEEP_PEAK * (1f - u)
                    }
                }
                try { mp.setVolume(g, g) } catch (_: Exception) { return }
                if (t < BEEP_FADE_END) handler.postDelayed(this, 50)
            }
        }
        handler.post(step)
    }

    // ------------------------------------------------- getar

    private fun vibrator(): Vibrator? = try {
        if (Build.VERSION.SDK_INT >= 31) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (_: Exception) { null }

    /** Getar berulang (0,8 dtk getar, 0,6 dtk jeda) sampai dihentikan lewat [stopVibration]. */
    private fun startVibration() {
        val v = vibrator() ?: return
        if (!v.hasVibrator()) return
        try {
            val effect = VibrationEffect.createWaveform(longArrayOf(0, 800, 600), 0)
            @Suppress("DEPRECATION")
            v.vibrate(
                effect,
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
        } catch (_: Exception) {}
    }

    private fun stopVibration() {
        try { vibrator()?.cancel() } catch (_: Exception) {}
    }

    // ------------------------------------------------- volume

    private fun am(): AudioManager = getSystemService(AudioManager::class.java)

    private fun volOf(stream: Int): Int =
        try { am().getStreamVolume(stream) } catch (_: Exception) { -1 }

    private fun ringerMode(): Int =
        try { am().ringerMode } catch (_: Exception) { -1 }

    private fun snapshot() = IntArray(watched.size) { volOf(watched[it]) }

    private fun changed(now: IntArray, ringer: Int): Boolean {
        for (i in now.indices) if (baseline[i] >= 0 && now[i] != baseline[i]) return true
        return baseRinger >= 0 && ringer != baseRinger
    }

    private fun setVol(stream: Int, v: Int) {
        try { am().setStreamVolume(stream, v, 0) } catch (_: Exception) {}
    }

    /**
     * - Volume alarm dinaikkan ke satu tingkat di bawah maksimum (kalau "naikkan otomatis" aktif).
     * - Stream yang sedang mentok di maksimum (alarm / musik / dering) diturunkan 1 tingkat
     *   sementara, supaya tombol volume naik MAUPUN turun sama-sama mengubah nilai dan bisa
     *   dideteksi. Semua dikembalikan ke nilai asli setelah selesai.
     */
    private fun prepareVolumes(autoVolume: Boolean, forDetection: Boolean) {
        restoreVolume()
        try {
            val m = am()
            val alarmMax = m.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            val alarmMid = if (alarmMax > 2) alarmMax - 1 else alarmMax
            val alarmCur = m.getStreamVolume(AudioManager.STREAM_ALARM)
            if ((autoVolume && alarmCur < alarmMid) || (forDetection && alarmCur > alarmMid)) {
                savedVol[AudioManager.STREAM_ALARM] = alarmCur
                setVol(AudioManager.STREAM_ALARM, alarmMid)
            }
            if (forDetection) {
                for (st in intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING)) {
                    val max = m.getStreamMaxVolume(st)
                    val cur = m.getStreamVolume(st)
                    if (max > 2 && cur >= max) {
                        savedVol[st] = cur
                        setVol(st, max - 1)
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private fun restoreVolume() {
        if (savedVol.isEmpty()) return
        for ((st, v) in savedVol) setVol(st, v)
        savedVol.clear()
    }

    // ------------------------------------------------- tombol volume = stop

    private fun armVolumeKeys() {
        // Patokan dicatat SETELAH aplikasi selesai mengatur volume, jadi tidak perlu masa tunggu:
        // perubahan apa pun sesudah ini pasti dari tombol volume.
        baseline = snapshot()
        baseRinger = ringerMode()

        // Jalur 0: cek semua stream volume tiap 0,05 detik
        handler.post(poller)

        // Jalur 1: sistem menyiarkan perubahan volume (stream apa pun) saat tombol ditekan
        try {
            ContextCompat.registerReceiver(
                this, volumeReceiver,
                IntentFilter().apply {
                    addAction("android.media.VOLUME_CHANGED_ACTION")
                    addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
                },
                ContextCompat.RECEIVER_EXPORTED
            )
            receiverRegistered = true
        } catch (_: Exception) {}

        // Jalur 2: MediaSession dengan kontrol volume sendiri, sehingga tombol tetap
        // terdeteksi walau volume sudah mentok (tidak ada perubahan untuk disiarkan)
        try {
            val provider = object : VolumeProvider(VolumeProvider.VOLUME_CONTROL_RELATIVE, 100, 50) {
                override fun onAdjustVolume(direction: Int) {
                    handler.post { onVolumeKey() }
                }
            }
            val ms = MediaSession(this, "AdzanVolumeStop")
            ms.setPlaybackToRemote(provider)
            ms.setPlaybackState(
                PlaybackState.Builder()
                    .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
                    .build()
            )
            ms.isActive = true
            session = ms
        } catch (_: Exception) {}
    }

    private fun disarmVolumeKeys() {
        handler.removeCallbacks(poller)
        if (receiverRegistered) {
            try { unregisterReceiver(volumeReceiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        session?.let {
            try { it.isActive = false; it.release() } catch (_: Exception) {}
        }
        session = null
    }

    private fun onVolumeKey() {
        if (notifId == 0) return // sudah berhenti
        finish()
    }

    private fun releasePlayer() {
        player?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        player = null
    }

    private fun closeAlarmScreen() {
        try { sendBroadcast(Intent(AlarmActivity.ACTION_FINISHED).setPackage(packageName)) } catch (_: Exception) {}
    }

    private fun finish() {
        handler.removeCallbacksAndMessages(null)
        closeAlarmScreen()
        disarmVolumeKeys()
        stopVibration()
        restoreVolume()
        releasePlayer()
        val wasRinging = notifId != 0
        if (wasRinging) {
            // Biarkan notifikasi tetap ada (bisa digeser), tapi bukan "ongoing" lagi
            stopForeground(STOP_FOREGROUND_DETACH)
            val n = NotificationHelper.build(
                this, NotificationHelper.CH_ALERT, title, text, ongoing = false, withStop = false
            )
            getSystemService(NotificationManager::class.java).notify(notifId, n)
            notifId = 0
        }
        // Alarm pra-adzan dihentikan (atau selesai): langsung tampilkan layar hitung mundur ke adzan,
        // dengan transisi memudar (layar alarm memudar keluar, layar hitung mundur memudar masuk)
        if (wasRinging && ringType == Scheduler.TYPE_PRE && ringAt > System.currentTimeMillis() + 5_000) {
            val prayer = Prayer.fromKey(ringPrayerKey)
            if (prayer != null) {
                CountdownActivity.launch(this, prayer, ringAt)
            }
        }
        stopSelf()
    }

    override fun onDestroy() {
        if (current === this) current = null
        handler.removeCallbacksAndMessages(null)
        closeAlarmScreen()
        disarmVolumeKeys()
        stopVibration()
        restoreVolume()
        releasePlayer()
        super.onDestroy()
    }
}
