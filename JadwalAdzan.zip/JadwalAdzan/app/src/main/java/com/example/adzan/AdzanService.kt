package com.example.adzan

import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.VolumeProvider
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.content.ContextCompat
import java.io.File

/**
 * Foreground service yang memainkan suara alarm / adzan, sehingga tetap hidup
 * walau aplikasi ditutup. Tombol "Hentikan" ada di notifikasi.
 *
 * Sumber suara (urut prioritas): MP3 yang dipilih di aplikasi -> `adzan.mp3` /
 * `alarm_pre.mp3` di res/raw -> nada bawaan HP.
 * Bisa dihentikan dengan tombol "Hentikan" atau tombol volume HP.
 */
class AdzanService : Service() {
    companion object {
        const val ACTION_STOP = "com.example.adzan.STOP"
    }

    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var notifId = 0
    private var title = ""
    private var text = ""

    private val queue = mutableListOf<Uri>()
    private var loop = false

    // Penghentian lewat tombol volume
    private var session: MediaSession? = null
    private var receiverRegistered = false

    // Tombol volume bisa mengubah stream mana saja (alarm / musik / dering), tergantung kondisi
    // layar & merek HP, jadi SEMUA stream dipantau, bukan hanya STREAM_ALARM.
    private val watched = intArrayOf(
        AudioManager.STREAM_ALARM, AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING,
        AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM
    )
    private var baseline = IntArray(watched.size) { -1 }
    private var baseRinger = -1
    private val savedVol = mutableMapOf<Int, Int>() // stream -> volume asli (untuk dikembalikan)

    private val poller = object : Runnable {
        override fun run() {
            if (changed(snapshot(), ringerMode())) {
                onVolumeKey()
                return
            }
            handler.postDelayed(this, 50)
        }
    }
    private val volumeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            // Siaran bisa datang telat akibat pengaturan volume dari aplikasi sendiri,
            // jadi hanya dianggap tombol volume kalau nilainya benar-benar beda dari patokan.
            if (changed(snapshot(), ringerMode())) onVolumeKey()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            finish()
            return START_NOT_STICKY
        }

        val type = intent.getIntExtra(Scheduler.EXTRA_TYPE, Scheduler.TYPE_ADZAN)
        val (t, x) = NotificationHelper.contentFor(this, intent)
        title = t
        text = x
        notifId = NotificationHelper.notificationId(intent.getStringExtra(Scheduler.EXTRA_PRAYER), type)

        NotificationHelper.ensureChannels(this)
        val n = NotificationHelper.build(
            this, NotificationHelper.CH_ALERT, title, text, ongoing = true, withStop = true
        )
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(notifId, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(notifId, n)
        }

        startSound(type)
        return START_NOT_STICKY
    }

    private fun startSound(type: Int) {
        handler.removeCallbacksAndMessages(null)
        disarmVolumeKeys() // bersihkan sisa alarm sebelumnya (mis. dua alarm berurutan)
        releasePlayer()
        queue.clear()

        val prefs = Prefs(this)
        // Urutan prioritas: MP3 pilihan pengguna -> res/raw -> nada bawaan HP
        val custom = prefs.soundPath(type)?.let { File(it) }?.takeIf { it.exists() }?.let { Uri.fromFile(it) }
        val name = if (type == Scheduler.TYPE_PRE) "alarm_pre" else "adzan"
        val rawId = resources.getIdentifier(name, "raw", packageName)
        val rawUri = if (rawId != 0) Uri.parse("android.resource://$packageName/$rawId") else null
        val defaultUri = RingtoneManager.getDefaultUri(
            if (type == Scheduler.TYPE_PRE) RingtoneManager.TYPE_ALARM
            else RingtoneManager.TYPE_NOTIFICATION
        )
        custom?.let { queue.add(it) }
        rawUri?.let { queue.add(it) }
        queue.add(defaultUri)

        val hasFile = custom != null || rawUri != null
        // Nada bawaan alarm diulang sampai dihentikan / 45 detik
        loop = !hasFile && type == Scheduler.TYPE_PRE
        val maxMs = if (hasFile && type == Scheduler.TYPE_ADZAN) 5 * 60_000L else 45_000L
        handler.postDelayed({ finish() }, maxMs)

        prepareVolumes(prefs.autoVolume, prefs.volumeStop)
        playNext()
        if (prefs.volumeStop) armVolumeKeys()
    }

    /** Putar URI berikutnya di antrean; kalau gagal, lanjut ke cadangan (bawaan HP). */
    private fun playNext() {
        releasePlayer()
        while (queue.isNotEmpty()) {
            val uri = queue.removeAt(0)
            val mp = MediaPlayer()
            try {
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                mp.setDataSource(this, uri)
                mp.setVolume(1f, 1f)
                mp.isLooping = loop
                mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
                mp.setOnPreparedListener { it.start() }
                mp.setOnCompletionListener { finish() }
                mp.setOnErrorListener { _, _, _ -> handler.post { playNext() }; true }
                mp.prepareAsync()
                player = mp
                return
            } catch (e: Exception) {
                try { mp.release() } catch (_: Exception) {}
            }
        }
        finish()
    }

    // ------------------------------------------------- volume

    private fun am(): AudioManager = getSystemService(AudioManager::class.java)

    private fun volOf(stream: Int): Int =
        try { am().getStreamVolume(stream) } catch (_: Exception) { -1 }

    private fun ringerMode(): Int =
        try { am().ringerMode } catch (_: Exception) { -1 }

    private fun snapshot() = IntArray(watched.size) { volOf(watched[it]) }

    private fun changed(now: IntArray, ringer: Int): Boolean {
        for (i in now.indices) if (baseline[i] >= 0 && now[i] != baseline[i]) return true
        return baseRinger >= 0 && ringer != baseRinger
    }

    private fun setVol(stream: Int, v: Int) {
        try { am().setStreamVolume(stream, v, 0) } catch (_: Exception) {}
    }

    /**
     * - Volume alarm dinaikkan ke satu tingkat di bawah maksimum (kalau "naikkan otomatis" aktif).
     * - Stream yang sedang mentok di maksimum (alarm / musik / dering) diturunkan 1 tingkat
     *   sementara, supaya tombol volume naik MAUPUN turun sama-sama mengubah nilai dan bisa
     *   dideteksi. Semua dikembalikan ke nilai asli setelah selesai.
     */
    private fun prepareVolumes(autoVolume: Boolean, forDetection: Boolean) {
        restoreVolume()
        try {
            val m = am()
            val alarmMax = m.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            val alarmMid = if (alarmMax > 2) alarmMax - 1 else alarmMax
            val alarmCur = m.getStreamVolume(AudioManager.STREAM_ALARM)
            if ((autoVolume && alarmCur < alarmMid) || (forDetection && alarmCur > alarmMid)) {
                savedVol[AudioManager.STREAM_ALARM] = alarmCur
                setVol(AudioManager.STREAM_ALARM, alarmMid)
            }
            if (forDetection) {
                for (st in intArrayOf(AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING)) {
                    val max = m.getStreamMaxVolume(st)
                    val cur = m.getStreamVolume(st)
                    if (max > 2 && cur >= max) {
                        savedVol[st] = cur
                        setVol(st, max - 1)
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private fun restoreVolume() {
        if (savedVol.isEmpty()) return
        for ((st, v) in savedVol) setVol(st, v)
        savedVol.clear()
    }

    // ------------------------------------------------- tombol volume = stop

    private fun armVolumeKeys() {
        // Patokan dicatat SETELAH aplikasi selesai mengatur volume, jadi tidak perlu masa tunggu:
        // perubahan apa pun sesudah ini pasti dari tombol volume.
        baseline = snapshot()
        baseRinger = ringerMode()

        // Jalur 0: cek semua stream volume tiap 0,05 detik
        handler.post(poller)

        // Jalur 1: sistem menyiarkan perubahan volume (stream apa pun) saat tombol ditekan
        try {
            ContextCompat.registerReceiver(
                this, volumeReceiver,
                IntentFilter().apply {
                    addAction("android.media.VOLUME_CHANGED_ACTION")
                    addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
                },
                ContextCompat.RECEIVER_EXPORTED
            )
            receiverRegistered = true
        } catch (_: Exception) {}

        // Jalur 2: MediaSession dengan kontrol volume sendiri, sehingga tombol tetap
        // terdeteksi walau volume sudah mentok (tidak ada perubahan untuk disiarkan)
        try {
            val provider = object : VolumeProvider(VolumeProvider.VOLUME_CONTROL_RELATIVE, 100, 50) {
                override fun onAdjustVolume(direction: Int) {
                    handler.post { onVolumeKey() }
                }
            }
            val ms = MediaSession(this, "AdzanVolumeStop")
            ms.setPlaybackToRemote(provider)
            ms.setPlaybackState(
                PlaybackState.Builder()
                    .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
                    .build()
            )
            ms.isActive = true
            session = ms
        } catch (_: Exception) {}
    }

    private fun disarmVolumeKeys() {
        handler.removeCallbacks(poller)
        if (receiverRegistered) {
            try { unregisterReceiver(volumeReceiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        session?.let {
            try { it.isActive = false; it.release() } catch (_: Exception) {}
        }
        session = null
    }

    private fun onVolumeKey() {
        if (notifId == 0) return // sudah berhenti
        finish()
    }

    private fun releasePlayer() {
        player?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        player = null
    }

    private fun finish() {
        handler.removeCallbacksAndMessages(null)
        disarmVolumeKeys()
        restoreVolume()
        releasePlayer()
        if (notifId != 0) {
            // Biarkan notifikasi tetap ada (bisa digeser), tapi bukan "ongoing" lagi
            stopForeground(STOP_FOREGROUND_DETACH)
            val n = NotificationHelper.build(
                this, NotificationHelper.CH_ALERT, title, text, ongoing = false, withStop = false
            )
            getSystemService(NotificationManager::class.java).notify(notifId, n)
            notifId = 0
        }
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        disarmVolumeKeys()
        restoreVolume()
        releasePlayer()
        super.onDestroy()
    }
}
