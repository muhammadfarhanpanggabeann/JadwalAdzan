package com.example.adzan

import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/**
 * Foreground service yang memainkan suara alarm / adzan, sehingga tetap hidup
 * walau aplikasi ditutup. Tombol "Hentikan" ada di notifikasi.
 *
 * Suara adzan sendiri: taruh file `adzan.mp3` di app/src/main/res/raw/
 * (opsional: `alarm_pre.mp3` untuk alarm pra-adzan). Tanpa file itu dipakai
 * nada bawaan HP.
 */
class AdzanService : Service() {
    companion object {
        const val ACTION_STOP = "com.example.adzan.STOP"
    }

    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var notifId = 0
    private var title = ""
    private var text = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            finish()
            return START_NOT_STICKY
        }

        val type = intent.getIntExtra(Scheduler.EXTRA_TYPE, Scheduler.TYPE_ADZAN)
        val (t, x) = NotificationHelper.contentFor(this, intent)
        title = t
        text = x
        notifId = NotificationHelper.notificationId(intent.getStringExtra(Scheduler.EXTRA_PRAYER), type)

        NotificationHelper.ensureChannels(this)
        val n = NotificationHelper.build(
            this, NotificationHelper.CH_ALERT, title, text, ongoing = true, withStop = true
        )
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(notifId, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(notifId, n)
        }

        startSound(type)
        return START_NOT_STICKY
    }

    private fun startSound(type: Int) {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()

        val name = if (type == Scheduler.TYPE_PRE) "alarm_pre" else "adzan"
        val rawId = resources.getIdentifier(name, "raw", packageName)
        val uri: Uri = if (rawId != 0) {
            Uri.parse("android.resource://$packageName/$rawId")
        } else {
            RingtoneManager.getDefaultUri(
                if (type == Scheduler.TYPE_PRE) RingtoneManager.TYPE_ALARM
                else RingtoneManager.TYPE_NOTIFICATION
            )
        }
        // Nada bawaan alarm diulang sampai dihentikan / 45 detik
        val loop = rawId == 0 && type == Scheduler.TYPE_PRE

        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(this, uri)
            mp.isLooping = loop
            mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener { finish() }
            mp.setOnErrorListener { _, _, _ -> finish(); true }
            mp.prepareAsync()
            player = mp
        } catch (e: Exception) {
            finish()
            return
        }

        val maxMs = if (rawId != 0 && type == Scheduler.TYPE_ADZAN) 5 * 60_000L else 45_000L
        handler.postDelayed({ finish() }, maxMs)
    }

    private fun releasePlayer() {
        player?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        player = null
    }

    private fun finish() {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        if (notifId != 0) {
            // Biarkan notifikasi tetap ada (bisa digeser), tapi bukan "ongoing" lagi
            stopForeground(STOP_FOREGROUND_DETACH)
            val n = NotificationHelper.build(
                this, NotificationHelper.CH_ALERT, title, text, ongoing = false, withStop = false
            )
            getSystemService(NotificationManager::class.java).notify(notifId, n)
            notifId = 0
        }
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        super.onDestroy()
    }
}
