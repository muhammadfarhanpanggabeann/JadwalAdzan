package com.example.adzan

import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.VolumeProvider
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.content.ContextCompat
import java.io.File

/**
 * Foreground service yang memainkan suara alarm / adzan, sehingga tetap hidup
 * walau aplikasi ditutup. Tombol "Hentikan" ada di notifikasi.
 *
 * Sumber suara (urut prioritas): MP3 yang dipilih di aplikasi -> `adzan.mp3` /
 * `alarm_pre.mp3` di res/raw -> nada bawaan HP.
 * Bisa dihentikan dengan tombol "Hentikan" atau tombol volume HP.
 */
class AdzanService : Service() {
    companion object {
        const val ACTION_STOP = "com.example.adzan.STOP"
    }

    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var notifId = 0
    private var title = ""
    private var text = ""

    private val queue = mutableListOf<Uri>()
    private var loop = false

    // Penghentian lewat tombol volume
    private var session: MediaSession? = null
    private var receiverRegistered = false
    private var armedAt = 0L
    private val volumeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val stream = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
            if (stream == AudioManager.STREAM_ALARM) onVolumeKey()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            finish()
            return START_NOT_STICKY
        }

        val type = intent.getIntExtra(Scheduler.EXTRA_TYPE, Scheduler.TYPE_ADZAN)
        val (t, x) = NotificationHelper.contentFor(this, intent)
        title = t
        text = x
        notifId = NotificationHelper.notificationId(intent.getStringExtra(Scheduler.EXTRA_PRAYER), type)

        NotificationHelper.ensureChannels(this)
        val n = NotificationHelper.build(
            this, NotificationHelper.CH_ALERT, title, text, ongoing = true, withStop = true
        )
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(notifId, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(notifId, n)
        }

        startSound(type)
        return START_NOT_STICKY
    }

    private fun startSound(type: Int) {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        queue.clear()

        val prefs = Prefs(this)
        // Urutan prioritas: MP3 pilihan pengguna -> res/raw -> nada bawaan HP
        val custom = prefs.soundPath(type)?.let { File(it) }?.takeIf { it.exists() }?.let { Uri.fromFile(it) }
        val name = if (type == Scheduler.TYPE_PRE) "alarm_pre" else "adzan"
        val rawId = resources.getIdentifier(name, "raw", packageName)
        val rawUri = if (rawId != 0) Uri.parse("android.resource://$packageName/$rawId") else null
        val defaultUri = RingtoneManager.getDefaultUri(
            if (type == Scheduler.TYPE_PRE) RingtoneManager.TYPE_ALARM
            else RingtoneManager.TYPE_NOTIFICATION
        )
        custom?.let { queue.add(it) }
        rawUri?.let { queue.add(it) }
        queue.add(defaultUri)

        val hasFile = custom != null || rawUri != null
        // Nada bawaan alarm diulang sampai dihentikan / 45 detik
        loop = !hasFile && type == Scheduler.TYPE_PRE
        val maxMs = if (hasFile && type == Scheduler.TYPE_ADZAN) 5 * 60_000L else 45_000L
        handler.postDelayed({ finish() }, maxMs)

        playNext()
        if (prefs.volumeStop) armVolumeKeys()
    }

    /** Putar URI berikutnya di antrean; kalau gagal, lanjut ke cadangan (bawaan HP). */
    private fun playNext() {
        releasePlayer()
        while (queue.isNotEmpty()) {
            val uri = queue.removeAt(0)
            val mp = MediaPlayer()
            try {
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                mp.setDataSource(this, uri)
                mp.isLooping = loop
                mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
                mp.setOnPreparedListener { it.start() }
                mp.setOnCompletionListener { finish() }
                mp.setOnErrorListener { _, _, _ -> handler.post { playNext() }; true }
                mp.prepareAsync()
                player = mp
                return
            } catch (e: Exception) {
                try { mp.release() } catch (_: Exception) {}
            }
        }
        finish()
    }

    // ------------------------------------------------- tombol volume = stop

    private fun armVolumeKeys() {
        // Abaikan perubahan volume dalam 0,8 detik pertama (bukan dari pengguna)
        armedAt = SystemClock.elapsedRealtime() + 800

        // Jalur 1: sistem menyiarkan perubahan volume alarm saat tombol ditekan
        try {
            ContextCompat.registerReceiver(
                this, volumeReceiver, IntentFilter("android.media.VOLUME_CHANGED_ACTION"),
                ContextCompat.RECEIVER_EXPORTED
            )
            receiverRegistered = true
        } catch (_: Exception) {}

        // Jalur 2: MediaSession dengan kontrol volume sendiri, sehingga tombol tetap
        // terdeteksi walau volume sudah mentok (tidak ada perubahan untuk disiarkan)
        try {
            val provider = object : VolumeProvider(VolumeProvider.VOLUME_CONTROL_RELATIVE, 100, 50) {
                override fun onAdjustVolume(direction: Int) {
                    handler.post { onVolumeKey() }
                }
            }
            val ms = MediaSession(this, "AdzanVolumeStop")
            ms.setPlaybackToRemote(provider)
            ms.setPlaybackState(
                PlaybackState.Builder()
                    .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
                    .build()
            )
            ms.isActive = true
            session = ms
        } catch (_: Exception) {}
    }

    private fun disarmVolumeKeys() {
        if (receiverRegistered) {
            try { unregisterReceiver(volumeReceiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        session?.let {
            try { it.isActive = false; it.release() } catch (_: Exception) {}
        }
        session = null
    }

    private fun onVolumeKey() {
        if (SystemClock.elapsedRealtime() < armedAt) return
        if (notifId == 0) return // sudah berhenti
        finish()
    }

    private fun releasePlayer() {
        player?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        player = null
    }

    private fun finish() {
        handler.removeCallbacksAndMessages(null)
        disarmVolumeKeys()
        releasePlayer()
        if (notifId != 0) {
            // Biarkan notifikasi tetap ada (bisa digeser), tapi bukan "ongoing" lagi
            stopForeground(STOP_FOREGROUND_DETACH)
            val n = NotificationHelper.build(
                this, NotificationHelper.CH_ALERT, title, text, ongoing = false, withStop = false
            )
            getSystemService(NotificationManager::class.java).notify(notifId, n)
            notifId = 0
        }
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        disarmVolumeKeys()
        releasePlayer()
        super.onDestroy()
    }
}
