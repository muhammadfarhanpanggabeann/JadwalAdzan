package com.example.adzan

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.switchmaterial.SwitchMaterial
import java.io.File
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var tvLocation: TextView
    private lateinit var tvDate: TextView
    private lateinit var tvNext: TextView
    private lateinit var tvCountdown: TextView
    private lateinit var prayerList: LinearLayout
    private lateinit var btnGps: MaterialButton
    private lateinit var btnNotifPerm: MaterialButton
    private lateinit var btnExact: MaterialButton
    private lateinit var btnBattery: MaterialButton
    private lateinit var btnPickAdzan: MaterialButton
    private lateinit var btnPickPre: MaterialButton

    private val handler = Handler(Looper.getMainLooper())
    private var zone: ZoneId = ZoneId.systemDefault()
    private var today: DayTimes? = null
    private var tomorrowSubuh: Long = 0L
    private var shownNext: Prayer? = null

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 1000)
        }
    }

    private val notifPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            updatePermissionButtons()
            askLocationOrUpdate()
        }

    private val locationPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            if (res.values.any { it }) updateLocation()
            else toast("Izin lokasi ditolak. Menampilkan jadwal untuk lokasi terakhir.")
        }

    private val pickAdzanLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importSound(uri, Scheduler.TYPE_ADZAN)
        }

    private val pickPreLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importSound(uri, Scheduler.TYPE_PRE)
        }

    private val Int.dp: Int get() = (this * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)
        NotificationHelper.ensureChannels(this)

        tvLocation = findViewById(R.id.tvLocation)
        tvDate = findViewById(R.id.tvDate)
        tvNext = findViewById(R.id.tvNext)
        tvCountdown = findViewById(R.id.tvCountdown)
        prayerList = findViewById(R.id.prayerList)
        btnGps = findViewById(R.id.btnGps)
        btnNotifPerm = findViewById(R.id.btnNotifPerm)
        btnExact = findViewById(R.id.btnExact)
        btnBattery = findViewById(R.id.btnBattery)

        btnPickAdzan = findViewById(R.id.btnPickAdzan)
        btnPickPre = findViewById(R.id.btnPickPre)

        btnGps.setOnClickListener { requestLocationFlow() }
        btnPickAdzan.setOnClickListener { chooseSound(Scheduler.TYPE_ADZAN) }
        btnPickPre.setOnClickListener { chooseSound(Scheduler.TYPE_PRE) }
        updateSoundButtons()

        bindSwitch(R.id.swAdzanNotif, prefs.adzanNotif) { prefs.adzanNotif = it; Scheduler.scheduleAll(this) }
        bindSwitch(R.id.swAdzanSound, prefs.adzanSound) { prefs.adzanSound = it }
        bindSwitch(R.id.swPreSound, prefs.preSound) { prefs.preSound = it }
        bindSwitch(R.id.swVolumeStop, prefs.volumeStop) { prefs.volumeStop = it }
        bindSwitch(R.id.swAutoVolume, prefs.autoVolume) { prefs.autoVolume = it }

        findViewById<MaterialButton>(R.id.btnAccessibility).setOnClickListener {
            toast("Pilih \"Jadwal Adzan\" lalu aktifkan. Jika dinonaktifkan sistem: Info Aplikasi ▸ ⋮ ▸ Izinkan setelan terbatas.")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btnNotifPerm.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33) notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        btnExact.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 31) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                )
            }
        }
        btnBattery.setOnClickListener {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        findViewById<MaterialButton>(R.id.btnTestPre).setOnClickListener {
            Scheduler.scheduleTest(this, Scheduler.TYPE_PRE)
            toast("Alarm pra-adzan uji coba akan bunyi dalam 5 detik. Boleh tutup app.")
        }
        findViewById<MaterialButton>(R.id.btnTestAdzan).setOnClickListener {
            Scheduler.scheduleTest(this, Scheduler.TYPE_ADZAN)
            toast("Adzan uji coba akan bunyi dalam 5 detik. Boleh tutup app.")
        }

        // Alur izin pertama kali: notifikasi -> lokasi
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            askLocationOrUpdate()
        }
    }

    override fun onResume() {
        super.onResume()
        updatePermissionButtons()
        render()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    // ---------------------------------------------------------------- lokasi

    private fun askLocationOrUpdate() {
        if (LocationHelper.hasPermission(this)) updateLocation()
        else locationPermLauncher.launch(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        )
    }

    private fun requestLocationFlow() {
        if (!LocationHelper.hasPermission(this)) {
            askLocationOrUpdate()
            return
        }
        if (!LocationHelper.isLocationEnabled(this)) {
            MaterialAlertDialogBuilder(this)
                .setTitle("GPS belum aktif")
                .setMessage("Aktifkan layanan lokasi agar jadwal sesuai posisi Anda.")
                .setPositiveButton("Buka pengaturan") { _, _ ->
                    startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                }
                .setNegativeButton("Batal", null)
                .show()
            return
        }
        updateLocation()
    }

    private fun updateLocation() {
        btnGps.isEnabled = false
        btnGps.text = "Mencari lokasi…"
        LocationHelper.fetch(this) { loc ->
            btnGps.isEnabled = true
            btnGps.text = "📍 Perbarui lokasi (GPS)"
            if (loc == null) {
                toast("Lokasi belum ditemukan. Pastikan GPS aktif lalu coba lagi.")
                return@fetch
            }
            prefs.lat = loc.latitude
            prefs.lon = loc.longitude
            prefs.city = "%.3f, %.3f".format(Locale.US, loc.latitude, loc.longitude)
            render()
            // Nama kota dicari di thread terpisah (butuh internet, boleh gagal)
            Thread {
                val name = LocationHelper.cityName(applicationContext, loc.latitude, loc.longitude)
                if (name != null) {
                    prefs.city = name
                    runOnUiThread { tvLocation.text = "📍 $name" ; Scheduler.scheduleAll(this) }
                }
            }.start()
        }
    }

    // ------------------------------------------------------------ tampilan

    private fun render() {
        zone = ZoneId.systemDefault()
        val d = LocalDate.now(zone)
        today = PrayerCalculator.compute(d, prefs.lat, prefs.lon, zone)
        tomorrowSubuh = PrayerCalculator.compute(d.plusDays(1), prefs.lat, prefs.lon, zone)
            .times.getValue(Prayer.SUBUH)

        tvLocation.text = "📍 ${prefs.city}"
        tvDate.text = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.forLanguageTag("id-ID")).format(d)
        renderRows()
        Scheduler.scheduleAll(this)
        tick()
    }

    private fun findNext(now: Long): Pair<Prayer, Long> {
        val t = today!!
        for (p in Prayer.alarmed) {
            val x = t.times.getValue(p)
            if (x > now) return p to x
        }
        return Prayer.SUBUH to tomorrowSubuh
    }

    private fun renderRows() {
        val t = today ?: return
        val (nextP, nextT) = findNext(System.currentTimeMillis())
        shownNext = nextP
        prayerList.removeAllViews()
        val inflater = LayoutInflater.from(this)

        for (p in Prayer.values()) {
            val row = inflater.inflate(R.layout.item_prayer, prayerList, false)
            val tvName = row.findViewById<TextView>(R.id.tvName)
            val tvTime = row.findViewById<TextView>(R.id.tvTime)
            val btnMin = row.findViewById<MaterialButton>(R.id.btnMinutes)
            val swPre = row.findViewById<SwitchMaterial>(R.id.swPre)

            val time = t.times.getValue(p)
            tvName.text = p.label
            tvTime.text = Fmt.time(time, zone)

            val isNext = p.hasAlarm && p == nextP && time == nextT
            if (isNext) {
                tvName.setTextColor(resolveColor(com.google.android.material.R.attr.colorPrimary))
                tvTime.setTextColor(resolveColor(com.google.android.material.R.attr.colorPrimary))
            }

            if (!p.hasAlarm) {
                btnMin.visibility = View.GONE
                swPre.visibility = View.GONE
            } else {
                btnMin.text = "⏰ ${prefs.preMinutes(p)} mnt"
                btnMin.setOnClickListener { pickMinutes(p, btnMin) }
                swPre.isChecked = prefs.preEnabled(p)
                swPre.setOnCheckedChangeListener { _, checked ->
                    prefs.setPreEnabled(p, checked)
                    Scheduler.scheduleAll(this)
                }
            }
            prayerList.addView(row)
        }
    }

    private fun tick() {
        val t = today ?: return
        if (t.date != LocalDate.now(zone)) {
            render()
            return
        }
        val now = System.currentTimeMillis()
        val (p, at) = findNext(now)
        if (p != shownNext) renderRows()
        tvNext.text = "Berikutnya: ${p.label} • ${Fmt.time(at, zone)}"
        val s = ((at - now) / 1000).coerceAtLeast(0)
        tvCountdown.text = "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    }

    private fun pickMinutes(p: Prayer, btn: MaterialButton) {
        val np = NumberPicker(this).apply {
            minValue = 1
            maxValue = 180
            value = prefs.preMinutes(p).coerceIn(1, 180)
            wrapSelectorWheel = false
        }
        val box = FrameLayout(this).apply {
            setPadding(0, 24.dp, 0, 0)
            addView(
                np,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            )
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Alarm ${p.label}: berapa menit sebelum adzan?")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                prefs.setPreMinutes(p, np.value)
                btn.text = "⏰ ${np.value} mnt"
                Scheduler.scheduleAll(this)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ------------------------------------------------------------ suara MP3

    private fun updateSoundButtons() {
        btnPickAdzan.text = "🕌 Suara adzan: ${prefs.soundName(Scheduler.TYPE_ADZAN) ?: "bawaan"}"
        btnPickPre.text = "⏰ Suara alarm pra-adzan: ${prefs.soundName(Scheduler.TYPE_PRE) ?: "bawaan"}"
    }

    private fun chooseSound(type: Int) {
        val label = if (type == Scheduler.TYPE_PRE) "alarm pra-adzan" else "adzan"
        MaterialAlertDialogBuilder(this)
            .setTitle("Suara $label")
            .setItems(arrayOf("Pilih file MP3 dari HP", "Pakai suara bawaan")) { _, which ->
                if (which == 0) {
                    val l = if (type == Scheduler.TYPE_PRE) pickPreLauncher else pickAdzanLauncher
                    l.launch(arrayOf("audio/*"))
                } else {
                    prefs.soundPath(type)?.let { File(it).delete() }
                    prefs.setSound(type, null, null)
                    updateSoundButtons()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    /** Salin file audio pilihan ke penyimpanan app, supaya tetap bisa diputar walau file asli dipindah. */
    private fun importSound(uri: Uri, type: Int) {
        Thread {
            try {
                var name = "audio"
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) name = c.getString(0) ?: name
                }
                val out = File(filesDir, "sound_$type.audio")
                val input = contentResolver.openInputStream(uri) ?: throw java.io.IOException("no stream")
                input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                prefs.setSound(type, out.absolutePath, name)
                runOnUiThread {
                    updateSoundButtons()
                    toast("Suara disimpan: $name. Coba lewat tombol uji coba.")
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Gagal membaca file audio.") }
            }
        }.start()
    }

    // --------------------------------------------------------------- izin

    private fun updatePermissionButtons() {
        btnNotifPerm.visibility =
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) View.VISIBLE else View.GONE

        btnExact.visibility = if (!Scheduler.canScheduleExact(this)) View.VISIBLE else View.GONE

        val pm = getSystemService(PowerManager::class.java)
        btnBattery.visibility = if (!pm.isIgnoringBatteryOptimizations(packageName)) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------- util

    private fun bindSwitch(id: Int, initial: Boolean, onChange: (Boolean) -> Unit) {
        val sw = findViewById<SwitchMaterial>(id)
        sw.isChecked = initial
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
    }

    private fun resolveColor(attr: Int): Int {
        val tv = android.util.TypedValue()
        theme.resolveAttribute(attr, tv, true)
        return tv.data
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
