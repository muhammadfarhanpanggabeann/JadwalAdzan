package com.example.adzan

import android.content.Context

/** Penyimpanan pengaturan sederhana (SharedPreferences). */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("adzan_prefs", Context.MODE_PRIVATE)

    // Default: Jakarta, sampai GPS berhasil dibaca
    var lat: Double
        get() = java.lang.Double.longBitsToDouble(
            sp.getLong("lat", java.lang.Double.doubleToRawLongBits(-6.2088))
        )
        set(v) = sp.edit().putLong("lat", java.lang.Double.doubleToRawLongBits(v)).apply()

    var lon: Double
        get() = java.lang.Double.longBitsToDouble(
            sp.getLong("lon", java.lang.Double.doubleToRawLongBits(106.8456))
        )
        set(v) = sp.edit().putLong("lon", java.lang.Double.doubleToRawLongBits(v)).apply()

    var city: String
        get() = sp.getString("city", "Jakarta (default)") ?: "Jakarta (default)"
        set(v) = sp.edit().putString("city", v).apply()

    /** Notifikasi saat waktu adzan tiba */
    var adzanNotif: Boolean
        get() = sp.getBoolean("adzan_notif", true)
        set(v) = sp.edit().putBoolean("adzan_notif", v).apply()

    /** Bunyikan suara saat adzan (kalau mati: notifikasi biasa) */
    var adzanSound: Boolean
        get() = sp.getBoolean("adzan_sound", true)
        set(v) = sp.edit().putBoolean("adzan_sound", v).apply()

    /** Bunyikan alarm pra-adzan (kalau mati: notifikasi biasa) */
    var preSound: Boolean
        get() = sp.getBoolean("pre_sound", true)
        set(v) = sp.edit().putBoolean("pre_sound", v).apply()

    fun preEnabled(p: Prayer): Boolean = sp.getBoolean("pre_on_${p.key}", true)
    fun setPreEnabled(p: Prayer, v: Boolean) = sp.edit().putBoolean("pre_on_${p.key}", v).apply()

    fun preMinutes(p: Prayer): Int = sp.getInt("pre_min_${p.key}", 10)
    fun setPreMinutes(p: Prayer, v: Int) = sp.edit().putInt("pre_min_${p.key}", v).apply()

    /** Matikan adzan/alarm yang sedang bunyi dengan menekan tombol volume */
    var volumeStop: Boolean
        get() = sp.getBoolean("volume_stop", true)
        set(v) = sp.edit().putBoolean("volume_stop", v).apply()

    /** File suara pilihan pengguna (salinan di penyimpanan app). type = Scheduler.TYPE_* */
    fun soundPath(type: Int): String? = sp.getString("sound_path_$type", null)
    fun soundName(type: Int): String? = sp.getString("sound_name_$type", null)
    fun setSound(type: Int, path: String?, name: String?) =
        sp.edit().putString("sound_path_$type", path).putString("sound_name_$type", name).apply()

    /** Naikkan volume alarm otomatis saat adzan/alarm bunyi (dikembalikan setelah selesai) */
    var autoVolume: Boolean
        get() = sp.getBoolean("auto_volume", true)
        set(v) = sp.edit().putBoolean("auto_volume", v).apply()
}
