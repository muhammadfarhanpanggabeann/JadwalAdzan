package com.example.adzan

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** Dipanggil OS saat alarm tiba — walau aplikasi sedang tertutup. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Jadwalkan ulang (menyambung rantai alarm & ganti hari)
        Scheduler.scheduleAll(context)

        val prefs = Prefs(context)
        val type = intent.getIntExtra(Scheduler.EXTRA_TYPE, Scheduler.TYPE_ADZAN)
        val prayerKey = intent.getStringExtra(Scheduler.EXTRA_PRAYER)
        val prayerAt = intent.getLongExtra(Scheduler.EXTRA_TIME, 0L)
        val prayer = Prayer.fromKey(prayerKey)

        NotificationHelper.ensureChannels(context)

        // Chip & layar hitung mundur: tidak membunyikan suara
        if (type == Scheduler.TYPE_CHIP) {
            if (prayer != null) NotificationHelper.showChip(context, prayer, prayerAt)
            return
        }
        if (type == Scheduler.TYPE_AOD) {
            if (prayer != null) CountdownActivity.launch(context, prayer, prayerAt)
            return
        }
        // Adzan tiba: chip hitung mundur sudah selesai tugasnya
        if (type == Scheduler.TYPE_ADZAN) NotificationHelper.cancelChip(context, prayerKey)

        val withSound = if (type == Scheduler.TYPE_PRE) prefs.preSound else prefs.adzanSound

        if (withSound) {
            try {
                ContextCompat.startForegroundService(
                    context,
                    Intent(context, AdzanService::class.java).putExtras(intent)
                )
                return
            } catch (e: Exception) {
                // OS menolak start service di latar belakang -> pakai notifikasi biasa
            }
        }
        NotificationHelper.notifyPlain(context, intent)
    }
}
