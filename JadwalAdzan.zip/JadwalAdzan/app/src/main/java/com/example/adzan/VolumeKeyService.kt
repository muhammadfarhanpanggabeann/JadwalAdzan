package com.example.adzan

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Menangkap tombol volume di mana pun (aplikasi lain, layar beranda, dll.) HANYA saat
 * adzan/alarm sedang bunyi. Di luar itu, tombol volume dibiarkan bekerja normal.
 * Tidak membaca isi layar; event aksesibilitas diabaikan.
 */
class VolumeKeyService : AccessibilityService() {
    private var consumeUpFor = -1

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val k = event.keyCode
        if (k != KeyEvent.KEYCODE_VOLUME_UP && k != KeyEvent.KEYCODE_VOLUME_DOWN &&
            k != KeyEvent.KEYCODE_VOLUME_MUTE
        ) return false

        // Lepas tombol setelah kita menghentikan alarm: telan juga supaya volume tidak bergeser
        if (event.action == KeyEvent.ACTION_UP && consumeUpFor == k) {
            consumeUpFor = -1
            return true
        }

        val svc = AdzanService.current ?: return false
        if (!svc.isRinging() || !Prefs(this).volumeStop) return false

        if (event.action == KeyEvent.ACTION_DOWN) {
            consumeUpFor = k
            svc.stopFromKey()
        }
        return true
    }
}
