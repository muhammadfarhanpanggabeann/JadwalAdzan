package com.example.adzan

import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.ZoneId

/** Menentukan adzan berikutnya (Subuh, Dzuhur, Ashar, Maghrib, Isya) dari waktu sekarang. */
object NextPrayer {
    fun find(ctx: Context, now: Long = System.currentTimeMillis()): Pair<Prayer, Long> {
        val prefs = Prefs(ctx)
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        for (d in 0..2) {
            val t = PrayerCalculator.compute(today.plusDays(d.toLong()), prefs.lat, prefs.lon, zone).times
            for (p in Prayer.alarmed) {
                val x = t.getValue(p)
                if (x > now + 1_000) return p to x
            }
        }
        return Prayer.SUBUH to now + 60_000L
    }
}

/**
 * Pengawas layar mati untuk mode "layar hitung mundur selalu aktif": sepanjang hari, setiap kali
 * layar mati (tombol daya, batas waktu layar, atau dari layar hitung mundur itu sendiri),
 * layar hitung mundur menuju adzan berikutnya menyala. Saat layar hidup layar itu tidak dibuka.
 */
class AlwaysOnService : Service() {

    companion object {
        private const val NOTIF_ID = 331

        /** Jalankan atau hentikan sesuai pengaturan. */
        fun sync(ctx: Context) {
            if (Prefs(ctx).aodAlways) start(ctx) else stop(ctx)
        }

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, AlwaysOnService::class.java))
            } catch (_: Exception) {
                // OS menolak start dari latar belakang; akan dicoba lagi saat app dibuka / alarm berikutnya
            }
        }

        fun stop(ctx: Context) {
            try { ctx.stopService(Intent(ctx, AlwaysOnService::class.java)) } catch (_: Exception) {}
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var receiverOn = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != Intent.ACTION_SCREEN_OFF) return
            if (!Prefs(context).aodAlways) return
            handler.postDelayed({
                val prefs = Prefs(applicationContext)
                val now = System.currentTimeMillis()
                val (prayer, at) = NextPrayer.find(applicationContext, now)
                // Sudah tiba waktu alarm salat ini (sampai adzan): pakai layar hitung mundur alarm
                // (menutup saat adzan tiba); di luar itu pakai mode selalu aktif (lanjut ke adzan berikutnya).
                val m = Scheduler.effectiveMinutes(prefs, prayer, java.time.LocalDate.now())
                val inAlarmWindow = prefs.preEnabled(prayer) && m > 0 && now >= at - m * 60_000L
                CountdownActivity.launch(applicationContext, prayer, at, always = !inAlarmWindow)
            }, 700)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (!Prefs(this).aodAlways) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!receiverOn) {
            ContextCompat.registerReceiver(
                this, screenReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED
            )
            receiverOn = true
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        NotificationHelper.ensureChannels(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, NotificationHelper.CH_FLOAT)
            .setSmallIcon(R.drawable.ic_stat_adzan)
            .setContentTitle("Layar hitung mundur selalu aktif")
            .setContentText("Layar hitung mundur adzan menyala setiap kali layar mati")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (receiverOn) {
            try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
            receiverOn = false
        }
        super.onDestroy()
    }
}
