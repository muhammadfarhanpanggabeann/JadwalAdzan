package com.example.adzan

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

enum class Prayer(val key: String, val label: String, val hasAlarm: Boolean) {
    SUBUH("subuh", "Subuh", true),
    TERBIT("terbit", "Terbit", false),
    DZUHUR("dzuhur", "Dzuhur", true),
    ASHAR("ashar", "Ashar", true),
    MAGHRIB("maghrib", "Maghrib", true),
    ISYA("isya", "Isya", true);

    companion object {
        val alarmed: List<Prayer> = values().filter { it.hasAlarm }
        fun fromKey(key: String?): Prayer? = values().firstOrNull { it.key == key }
    }
}

/** Waktu salat satu hari, dalam epoch millis. */
data class DayTimes(val date: LocalDate, val times: Map<Prayer, Long>)

object Fmt {
    private val tf = DateTimeFormatter.ofPattern("HH:mm")
    fun time(ms: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        tf.format(Instant.ofEpochMilli(ms).atZone(zone))

    /** Hitung mundur: MM:SS, atau H:MM:SS kalau lebih dari satu jam. */
    fun countdown(totalSec: Long): String =
        if (totalSec >= 3600) {
            String.format(Locale.US, "%d:%02d:%02d", totalSec / 3600, (totalSec % 3600) / 60, totalSec % 60)
        } else {
            String.format(Locale.US, "%02d:%02d", totalSec / 60, totalSec % 60)
        }
}

/**
 * Perhitungan waktu salat offline (tanpa internet), metode Kemenag RI:
 * Subuh 20°, Isya 18°, Ashar mazhab Syafi'i (bayangan = 1x tinggi benda),
 * ditambah ihtiyat (pengaman) 2 menit.
 */
object PrayerCalculator {
    private const val FAJR_ANGLE = 20.0
    private const val ISHA_ANGLE = 18.0
    private const val SUN_ANGLE = 0.833

    private val IHTIYAT = mapOf(
        Prayer.SUBUH to 2,
        Prayer.TERBIT to -2,
        Prayer.DZUHUR to 2,
        Prayer.ASHAR to 2,
        Prayer.MAGHRIB to 2,
        Prayer.ISYA to 2,
    )

    fun compute(date: LocalDate, lat: Double, lon: Double, zone: ZoneId): DayTimes {
        val noon = date.atTime(12, 0).atZone(zone).toInstant()
        val tz = zone.rules.getOffset(noon).totalSeconds / 3600.0
        val jd = julian(date.year, date.monthValue, date.dayOfMonth) - lon / (15.0 * 24.0)
        val adj = tz - lon / 15.0

        val raw = linkedMapOf(
            Prayer.SUBUH to sunAngleTime(jd, lat, FAJR_ANGLE, 5.0 / 24, true),
            Prayer.TERBIT to sunAngleTime(jd, lat, SUN_ANGLE, 6.0 / 24, true),
            Prayer.DZUHUR to midDay(jd, 12.0 / 24),
            Prayer.ASHAR to asrTime(jd, lat, 1.0, 13.0 / 24),
            Prayer.MAGHRIB to sunAngleTime(jd, lat, SUN_ANGLE, 18.0 / 24, false),
            Prayer.ISYA to sunAngleTime(jd, lat, ISHA_ANGLE, 18.0 / 24, false),
        )

        val base = date.atStartOfDay(zone).toInstant().toEpochMilli()
        val out = LinkedHashMap<Prayer, Long>()
        for ((p, h0) in raw) {
            val h = h0 + adj
            val minutes = if (p == Prayer.TERBIT) floor(h * 60.0) else ceil(h * 60.0)
            out[p] = base + (minutes.toLong() + IHTIYAT.getValue(p)) * 60_000L
        }
        return DayTimes(date, out)
    }

    // ---------- astronomi ----------
    private fun dsin(d: Double) = sin(Math.toRadians(d))
    private fun dcos(d: Double) = cos(Math.toRadians(d))
    private fun dtan(d: Double) = tan(Math.toRadians(d))
    private fun darcsin(x: Double) = Math.toDegrees(asin(x))
    private fun darccos(x: Double) = Math.toDegrees(acos(x))
    private fun darctan2(y: Double, x: Double) = Math.toDegrees(atan2(y, x))
    private fun darccot(x: Double) = Math.toDegrees(atan(1.0 / x))

    private fun fix(a: Double, mode: Double): Double {
        val r = a - mode * floor(a / mode)
        return if (r < 0) r + mode else r
    }

    private fun fixAngle(a: Double) = fix(a, 360.0)
    private fun fixHour(a: Double) = fix(a, 24.0)

    private fun julian(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    /** @return pasangan (deklinasi matahari, equation of time dalam jam) */
    private fun sunPosition(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g))
        val e = 23.439 - 0.00000036 * d
        val ra = fixHour(darctan2(dcos(e) * dsin(l), dcos(l)) / 15.0)
        val eqt = q / 15.0 - ra
        val decl = darcsin(dsin(e) * dsin(l))
        return decl to eqt
    }

    private fun midDay(jd: Double, t: Double): Double = fixHour(12.0 - sunPosition(jd + t).second)

    private fun sunAngleTime(jd: Double, lat: Double, angle: Double, t: Double, ccw: Boolean): Double {
        val decl = sunPosition(jd + t).first
        val noon = midDay(jd, t)
        val x = (-dsin(angle) - dsin(decl) * dsin(lat)) / (dcos(decl) * dcos(lat))
        val dt = darccos(x.coerceIn(-1.0, 1.0)) / 15.0
        return noon + if (ccw) -dt else dt
    }

    private fun asrTime(jd: Double, lat: Double, factor: Double, t: Double): Double {
        val decl = sunPosition(jd + t).first
        val angle = -darccot(factor + dtan(abs(lat - decl)))
        return sunAngleTime(jd, lat, angle, t, false)
    }
}
