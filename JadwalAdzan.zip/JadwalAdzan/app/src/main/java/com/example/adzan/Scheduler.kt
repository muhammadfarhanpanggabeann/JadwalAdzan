package com.example.adzan

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.LocalDate
import java.time.ZoneId

/**
 * Menjadwalkan alarm sistem (AlarmManager) untuk 3 hari ke depan.
 * Alarm dikelola OS, jadi tetap bunyi walau app ditutup / di-swipe.
 * Dijadwalkan ulang: saat app dibuka, setelah reboot, ganti zona waktu/jam,
 * dan setiap kali satu alarm berbunyi.
 */
object Scheduler {
    const val ACTION_ALARM = "com.example.adzan.ALARM"
    const val EXTRA_PRAYER = "prayer"
    const val EXTRA_TYPE = "type"
    const val EXTRA_TIME = "time"
    const val EXTRA_MIN = "min"
    const val TYPE_PRE = 0
    const val TYPE_ADZAN = 1

    private const val DAYS = 3
    private const val TEST_CODE_BASE = 9000

    fun canScheduleExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        return ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    }

    fun scheduleAll(ctx: Context) {
        val app = ctx.applicationContext
        val am = app.getSystemService(AlarmManager::class.java)
        val prefs = Prefs(app)
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        val now = System.currentTimeMillis()

        for (d in 0 until DAYS) {
            val day = PrayerCalculator.compute(today.plusDays(d.toLong()), prefs.lat, prefs.lon, zone)
            for ((i, prayer) in Prayer.alarmed.withIndex()) {
                val t = day.times.getValue(prayer)

                // Alarm sebelum adzan
                val preCode = requestCode(d, i, TYPE_PRE)
                cancel(app, am, preCode)
                val minutes = prefs.preMinutes(prayer)
                val preAt = t - minutes * 60_000L
                if (prefs.preEnabled(prayer) && minutes > 0 && preAt > now + 5_000) {
                    set(app, am, preAt, preCode, prayer, TYPE_PRE, t, minutes)
                }

                // Notifikasi / suara saat adzan
                val adzanCode = requestCode(d, i, TYPE_ADZAN)
                cancel(app, am, adzanCode)
                if (prefs.adzanNotif && t > now + 5_000) {
                    set(app, am, t, adzanCode, prayer, TYPE_ADZAN, t, 0)
                }
            }
        }
    }

    /** Alarm uji coba 5 detik dari sekarang. */
    fun scheduleTest(ctx: Context, type: Int) {
        val app = ctx.applicationContext
        val am = app.getSystemService(AlarmManager::class.java)
        val at = System.currentTimeMillis() + 5_000
        val shownTime = if (type == TYPE_PRE) at + 10 * 60_000L else at
        set(app, am, at, TEST_CODE_BASE + type, Prayer.DZUHUR, type, shownTime, 10)
    }

    private fun requestCode(day: Int, prayerIndex: Int, type: Int) = day * 100 + prayerIndex * 10 + type

    private fun baseIntent(app: Context) =
        Intent(app, AlarmReceiver::class.java).setAction(ACTION_ALARM)

    private fun cancel(app: Context, am: AlarmManager, code: Int) {
        val pi = PendingIntent.getBroadcast(
            app, code, baseIntent(app),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            am.cancel(pi)
            pi.cancel()
        }
    }

    private fun set(
        app: Context, am: AlarmManager, triggerAt: Long, code: Int,
        prayer: Prayer, type: Int, prayerTime: Long, minutes: Int
    ) {
        val intent = baseIntent(app)
            .putExtra(EXTRA_PRAYER, prayer.key)
            .putExtra(EXTRA_TYPE, type)
            .putExtra(EXTRA_TIME, prayerTime)
            .putExtra(EXTRA_MIN, minutes)
        val pi = PendingIntent.getBroadcast(
            app, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val show = PendingIntent.getActivity(
            app, 0, Intent(app, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        try {
            // setAlarmClock = jenis alarm paling andal: menembus Doze & hemat baterai agresif.
            am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, show), pi)
        } catch (e: SecurityException) {
            // Izin alarm tepat waktu belum diberikan: pakai alarm biasa (bisa meleset beberapa menit)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }
}
