package com.example.adzan

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** Ambil lokasi GPS perangkat (Fused Location, cadangan: LocationManager). */
object LocationHelper {

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun isLocationEnabled(ctx: Context): Boolean =
        LocationManagerCompat.isLocationEnabled(ctx.getSystemService(LocationManager::class.java))

    @SuppressLint("MissingPermission")
    fun fetch(ctx: Context, onResult: (Location?) -> Unit) {
        if (!hasPermission(ctx)) {
            onResult(null)
            return
        }
        val app = ctx.applicationContext
        val done = AtomicBoolean(false)
        val main = Handler(Looper.getMainLooper())
        fun deliver(loc: Location?) {
            if (done.compareAndSet(false, true)) onResult(loc)
        }

        val client = LocationServices.getFusedLocationProviderClient(app)
        val cts = CancellationTokenSource()

        fun fallback() {
            client.lastLocation
                .addOnSuccessListener { loc -> deliver(loc ?: legacyLastKnown(app)) }
                .addOnFailureListener { deliver(legacyLastKnown(app)) }
        }

        // Batas waktu 15 detik (mis. di dalam gedung)
        main.postDelayed({
            if (!done.get()) {
                cts.cancel()
                fallback()
            }
        }, 15_000)

        client.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, cts.token)
            .addOnSuccessListener { loc -> if (loc != null) deliver(loc) else fallback() }
            .addOnFailureListener { fallback() }
    }

    @SuppressLint("MissingPermission")
    private fun legacyLastKnown(ctx: Context): Location? {
        return try {
            val lm = ctx.getSystemService(LocationManager::class.java)
            lm.getProviders(true)
                .mapNotNull { lm.getLastKnownLocation(it) }
                .maxByOrNull { it.time }
        } catch (e: Exception) {
            null
        }
    }

    /** Nama kota dari koordinat. Panggil dari thread background. Bisa null jika offline. */
    @Suppress("DEPRECATION")
    fun cityName(ctx: Context, lat: Double, lon: Double): String? {
        return try {
            val g = Geocoder(ctx, Locale.forLanguageTag("id-ID"))
            val a: Address? = g.getFromLocation(lat, lon, 1)?.firstOrNull()
            a?.subAdminArea ?: a?.locality ?: a?.adminArea
        } catch (e: Exception) {
            null
        }
    }
}
