package com.example.adzan

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.core.app.NotificationCompat

object NotificationHelper {
    /** Channel untuk alarm/adzan yang suaranya dimainkan oleh AdzanService. */
    const val CH_ALERT = "adzan_alert"

    /** Channel untuk notifikasi biasa (suara default sistem). */
    const val CH_PLAIN = "adzan_plain"

    /** Channel chip / notifikasi live hitung mundur (senyap). */
    const val CH_COUNTDOWN = "adzan_countdown"

    /** Channel pembuka layar hitung mundur di atas layar kunci (senyap, prioritas tinggi). */
    const val CH_AOD = "adzan_aod"

    /** Channel notifikasi layanan kapsul melayang (kecil & senyap). */
    const val CH_FLOAT = "adzan_float"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val alert = NotificationChannel(CH_ALERT, "Alarm & adzan", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Alarm sebelum adzan dan saat adzan (suara dimainkan oleh aplikasi)"
            setSound(null, null)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 500, 300, 500)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val plain = NotificationChannel(CH_PLAIN, "Notifikasi waktu salat", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Notifikasi biasa dengan suara notifikasi bawaan"
            enableVibration(true)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val countdown = NotificationChannel(CH_COUNTDOWN, "Hitung mundur adzan", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Chip / notifikasi live yang menghitung mundur menjelang adzan"
            setSound(null, null)
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val aod = NotificationChannel(CH_AOD, "Layar hitung mundur", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Membuka layar hitung mundur di atas layar kunci menjelang adzan"
            setSound(null, null)
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val floatCh = NotificationChannel(CH_FLOAT, "Kapsul melayang", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Notifikasi kecil saat kapsul hitung mundur melayang aktif"
            setSound(null, null)
            enableVibration(false)
        }
        nm.createNotificationChannels(listOf(alert, plain, countdown, aod, floatCh))
    }

    private fun prayerIndex(key: String?) =
        Prayer.alarmed.indexOfFirst { it.key == key }.coerceAtLeast(0)

    fun chipId(key: String?) = 300 + prayerIndex(key)
    fun aodId(key: String?) = 320 + prayerIndex(key)

    /**
     * Chip / notifikasi live hitung mundur menjelang adzan.
     * - Android 16+: tampil sebagai chip kapsul di status bar (Live Updates) dengan hitungan mundur.
     * - Android lebih lama: notifikasi menetap dengan hitung mundur (tidak bisa digeser/dihapus).
     * Hilang sendiri tepat saat alarm berbunyi (setTimeoutAfter) dan dibatalkan oleh AlarmReceiver.
     */
    fun showChip(ctx: Context, prayer: Prayer, at: Long, force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (at <= now) return
        ensureChannels(ctx)
        val prefs = Prefs(ctx)

        // Chip mengikuti alarm; `at` = waktu bunyi alarm itu. Hanya dipanggil bila alarmnya aktif.

        // Kapsul melayang di atas aplikasi lain (kalau diaktifkan & izin "Muncul di atas" ada)
        FloatingChipService.start(ctx, prayer, at, bubble = true, watch = false)

        val idx = prayerIndex(prayer.key)
        val open = PendingIntent.getActivity(
            ctx, 400 + idx, CountdownActivity.intentFor(ctx, prayer.key, at),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val extras = Bundle().apply {
            // Minta tampil sebagai Live Update / chip status bar (Android 16+). Diabaikan di versi lama.
            putBoolean("android.requestPromotedOngoing", true)
        }
        val n = NotificationCompat.Builder(ctx, CH_COUNTDOWN)
            .setSmallIcon(R.drawable.ic_stat_adzan)
            .setContentTitle("Alarm ${prayer.label} • ${Fmt.time(at)}")
            .setContentText(prefs.city)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setShowWhen(true)
            .setWhen(at)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setTimeoutAfter(at - now)
            .setContentIntent(open)
            .addExtras(extras)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(chipId(prayer.key), n)
    }

    fun cancelChip(ctx: Context, prayerKey: String?) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.cancel(chipId(prayerKey))
        nm.cancel(aodId(prayerKey))
        FloatingChipService.stop(ctx)
    }

    /** Membuka layar hitung mundur di atas layar kunci lewat notifikasi layar penuh. */
    fun showCountdownFullScreen(ctx: Context, prayer: Prayer, at: Long, preview: Boolean = false) {
        val now = System.currentTimeMillis()
        if (at <= now) return
        ensureChannels(ctx)
        val idx = prayerIndex(prayer.key)
        val always = Prefs(ctx).aodAlways && !preview
        val screen = PendingIntent.getActivity(
            ctx, 410 + idx, CountdownActivity.intentFor(ctx, prayer.key, at, preview),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CH_AOD)
            .setSmallIcon(R.drawable.ic_stat_adzan)
            .setContentTitle(if (always) "Hitung mundur adzan ${prayer.label}" else "Sebentar lagi alarm ${prayer.label}")
            .setContentText("Pukul ${Fmt.time(at)} • ${Prefs(ctx).city}")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .setAutoCancel(true)
            // Mode selalu aktif: adzan bisa berjam-jam lagi, jadi notifikasi pembuka tidak dibiarkan lama
            .setTimeoutAfter(if (always) minOf(at - now, 2 * 60_000L) else at - now)
            .setContentIntent(screen)
            .setFullScreenIntent(screen, true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(aodId(prayer.key), n)
    }

    fun notificationId(prayerKey: String?, type: Int): Int {
        val idx = Prayer.alarmed.indexOfFirst { it.key == prayerKey }.coerceAtLeast(0)
        return 100 + idx * 2 + type
    }

    fun contentFor(ctx: Context, i: Intent): Pair<String, String> {
        val prayer = Prayer.fromKey(i.getStringExtra(Scheduler.EXTRA_PRAYER)) ?: Prayer.DZUHUR
        val time = Fmt.time(i.getLongExtra(Scheduler.EXTRA_TIME, System.currentTimeMillis()))
        val type = i.getIntExtra(Scheduler.EXTRA_TYPE, Scheduler.TYPE_ADZAN)
        val city = Prefs(ctx).city
        return if (type == Scheduler.TYPE_PRE) {
            val m = i.getIntExtra(Scheduler.EXTRA_MIN, 10)
            "Sebentar lagi adzan ${prayer.label}" to "$m menit lagi • pukul $time • $city"
        } else {
            "Waktunya adzan ${prayer.label}" to "Pukul $time • $city"
        }
    }

    fun build(
        ctx: Context, channel: String, title: String, text: String,
        ongoing: Boolean, withStop: Boolean
    ): Notification {
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_adzan)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .setAutoCancel(!ongoing)
            .setOngoing(ongoing)
            .setContentIntent(open)
        if (withStop) {
            val stop = PendingIntent.getService(
                ctx, 1,
                Intent(ctx, AdzanService::class.java).setAction(AdzanService.ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE
            )
            b.addAction(0, "Hentikan", stop)

            // Layar alarm di atas layar kunci (supaya tombol volume pasti tertangkap)
            val screen = PendingIntent.getActivity(
                ctx, 2,
                Intent(ctx, AlarmActivity::class.java)
                    .putExtra(AlarmActivity.EXTRA_TITLE, title)
                    .putExtra(AlarmActivity.EXTRA_TEXT, text)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.setFullScreenIntent(screen, true)
        }
        return b.build()
    }

    fun notifyPlain(ctx: Context, intent: Intent) {
        val (title, text) = contentFor(ctx, intent)
        val type = intent.getIntExtra(Scheduler.EXTRA_TYPE, Scheduler.TYPE_ADZAN)
        val id = notificationId(intent.getStringExtra(Scheduler.EXTRA_PRAYER), type)
        val n = build(ctx, CH_PLAIN, title, text, ongoing = false, withStop = false)
        ctx.getSystemService(NotificationManager::class.java).notify(id, n)
    }
}
