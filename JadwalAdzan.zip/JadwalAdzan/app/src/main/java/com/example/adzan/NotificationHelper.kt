package com.example.adzan

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

object NotificationHelper {
    /** Channel untuk alarm/adzan yang suaranya dimainkan oleh AdzanService. */
    const val CH_ALERT = "adzan_alert"

    /** Channel untuk notifikasi biasa (suara default sistem). */
    const val CH_PLAIN = "adzan_plain"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val alert = NotificationChannel(CH_ALERT, "Alarm & adzan", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Alarm sebelum adzan dan saat adzan (suara dimainkan oleh aplikasi)"
            setSound(null, null)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 500, 300, 500)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val plain = NotificationChannel(CH_PLAIN, "Notifikasi waktu salat", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Notifikasi biasa dengan suara notifikasi bawaan"
            enableVibration(true)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannels(listOf(alert, plain))
    }

    fun notificationId(prayerKey: String?, type: Int): Int {
        val idx = Prayer.alarmed.indexOfFirst { it.key == prayerKey }.coerceAtLeast(0)
        return 100 + idx * 2 + type
    }

    fun contentFor(ctx: Context, i: Intent): Pair<String, String> {
        val prayer = Prayer.fromKey(i.getStringExtra(Scheduler.EXTRA_PRAYER)) ?: Prayer.DZUHUR
        val time = Fmt.time(i.getLongExtra(Scheduler.EXTRA_TIME, System.currentTimeMillis()))
        val type = i.getIntExtra(Scheduler.EXTRA_TYPE, Scheduler.TYPE_ADZAN)
        val city = Prefs(ctx).city
        return if (type == Scheduler.TYPE_PRE) {
            val m = i.getIntExtra(Scheduler.EXTRA_MIN, 10)
            "Sebentar lagi adzan ${prayer.label}" to "$m menit lagi • pukul $time • $city"
        } else {
            "Waktunya adzan ${prayer.label}" to "Pukul $time • $city"
        }
    }

    fun build(
        ctx: Context, channel: String, title: String, text: String,
        ongoing: Boolean, withStop: Boolean
    ): Notification {
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_adzan)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .setAutoCancel(!ongoing)
            .setOngoing(ongoing)
            .setContentIntent(open)
        if (withStop) {
            val stop = PendingIntent.getService(
                ctx, 1,
                Intent(ctx, AdzanService::class.java).setAction(AdzanService.ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE
            )
            b.addAction(0, "Hentikan", stop)

            // Layar alarm di atas layar kunci (supaya tombol volume pasti tertangkap)
            val screen = PendingIntent.getActivity(
                ctx, 2,
                Intent(ctx, AlarmActivity::class.java)
                    .putExtra(AlarmActivity.EXTRA_TITLE, title)
                    .putExtra(AlarmActivity.EXTRA_TEXT, text)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.setFullScreenIntent(screen, true)
        }
        return b.build()
    }

    fun notifyPlain(ctx: Context, intent: Intent) {
        val (title, text) = contentFor(ctx, intent)
        val type = intent.getIntExtra(Scheduler.EXTRA_TYPE, Scheduler.TYPE_ADZAN)
        val id = notificationId(intent.getStringExtra(Scheduler.EXTRA_PRAYER), type)
        val n = build(ctx, CH_PLAIN, title, text, ongoing = false, withStop = false)
        ctx.getSystemService(NotificationManager::class.java).notify(id, n)
    }
}
